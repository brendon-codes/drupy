-- MySQL dump 10.11
--
-- Host: localhost    Database: drupalhead
-- ------------------------------------------------------
-- Server version	5.0.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `actions` (
  `aid` varchar(255) NOT NULL default '0',
  `type` varchar(32) NOT NULL default '',
  `callback` varchar(255) NOT NULL default '',
  `parameters` longtext NOT NULL,
  `description` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` (`aid`, `type`, `callback`, `parameters`, `description`) VALUES ('comment_unpublish_action','comment','comment_unpublish_action','','Unpublish comment'),('node_publish_action','node','node_publish_action','','Publish post'),('node_unpublish_action','node','node_unpublish_action','','Unpublish post'),('node_make_sticky_action','node','node_make_sticky_action','','Make post sticky'),('node_make_unsticky_action','node','node_make_unsticky_action','','Make post unsticky'),('node_promote_action','node','node_promote_action','','Promote post to front page'),('node_unpromote_action','node','node_unpromote_action','','Remove post from front page'),('node_save_action','node','node_save_action','','Save post'),('system_block_ip_action','user','system_block_ip_action','','Ban IP address of current user'),('user_block_user_action','user','user_block_user_action','','Block current user');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions_aid`
--

DROP TABLE IF EXISTS `actions_aid`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `actions_aid` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `actions_aid`
--

LOCK TABLES `actions_aid` WRITE;
/*!40000 ALTER TABLE `actions_aid` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions_aid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authmap`
--

DROP TABLE IF EXISTS `authmap`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `authmap` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `authname` varchar(128) NOT NULL default '',
  `module` varchar(128) NOT NULL default '',
  PRIMARY KEY  (`aid`),
  UNIQUE KEY `authname` (`authname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `authmap`
--

LOCK TABLES `authmap` WRITE;
/*!40000 ALTER TABLE `authmap` DISABLE KEYS */;
/*!40000 ALTER TABLE `authmap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `batch` (
  `bid` int(10) unsigned NOT NULL auto_increment,
  `token` varchar(64) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `batch` longtext,
  PRIMARY KEY  (`bid`),
  KEY `token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `batch`
--

LOCK TABLES `batch` WRITE;
/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blocked_ips` (
  `iid` int(10) unsigned NOT NULL auto_increment,
  `ip` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`iid`),
  KEY `blocked_ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blocks` (
  `bid` int(11) NOT NULL auto_increment,
  `module` varchar(64) NOT NULL default '',
  `delta` varchar(32) NOT NULL default '0',
  `theme` varchar(64) NOT NULL default '',
  `status` tinyint(4) NOT NULL default '0',
  `weight` tinyint(4) NOT NULL default '0',
  `region` varchar(64) NOT NULL default '',
  `custom` tinyint(4) NOT NULL default '0',
  `visibility` tinyint(4) NOT NULL default '0',
  `pages` text NOT NULL,
  `title` varchar(64) NOT NULL default '',
  `cache` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `tmd` (`theme`,`module`,`delta`),
  KEY `list` (`theme`,`status`,`region`,`weight`,`module`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` (`bid`, `module`, `delta`, `theme`, `status`, `weight`, `region`, `custom`, `visibility`, `pages`, `title`, `cache`) VALUES (1,'user','login','garland',1,0,'left',0,0,'','',-1),(2,'user','navigation','garland',1,0,'left',0,0,'','',-1),(3,'system','powered-by','garland',1,10,'footer',0,0,'','',-1);
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks_roles`
--

DROP TABLE IF EXISTS `blocks_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blocks_roles` (
  `module` varchar(64) NOT NULL,
  `delta` varchar(32) NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`module`,`delta`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blocks_roles`
--

LOCK TABLES `blocks_roles` WRITE;
/*!40000 ALTER TABLE `blocks_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boxes`
--

DROP TABLE IF EXISTS `boxes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `boxes` (
  `bid` int(10) unsigned NOT NULL auto_increment,
  `body` longtext,
  `info` varchar(128) NOT NULL default '',
  `format` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`bid`),
  UNIQUE KEY `info` (`info`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `boxes`
--

LOCK TABLES `boxes` WRITE;
/*!40000 ALTER TABLE `boxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `boxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_block`
--

DROP TABLE IF EXISTS `cache_block`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_block` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_block`
--

LOCK TABLES `cache_block` WRITE;
/*!40000 ALTER TABLE `cache_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_filter`
--

DROP TABLE IF EXISTS `cache_filter`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_filter` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_filter`
--

LOCK TABLES `cache_filter` WRITE;
/*!40000 ALTER TABLE `cache_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_form`
--

DROP TABLE IF EXISTS `cache_form`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_form` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_form`
--

LOCK TABLES `cache_form` WRITE;
/*!40000 ALTER TABLE `cache_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_menu`
--

DROP TABLE IF EXISTS `cache_menu`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_menu` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_menu`
--

LOCK TABLES `cache_menu` WRITE;
/*!40000 ALTER TABLE `cache_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_page`
--

DROP TABLE IF EXISTS `cache_page`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_page` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_page`
--

LOCK TABLES `cache_page` WRITE;
/*!40000 ALTER TABLE `cache_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_registry`
--

DROP TABLE IF EXISTS `cache_registry`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_registry` (
  `cid` varchar(255) NOT NULL default '',
  `data` longblob,
  `expire` int(11) NOT NULL default '0',
  `created` int(11) NOT NULL default '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_registry`
--

LOCK TABLES `cache_registry` WRITE;
/*!40000 ALTER TABLE `cache_registry` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `comments` (
  `cid` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL default '0',
  `nid` int(11) NOT NULL default '0',
  `uid` int(11) NOT NULL default '0',
  `subject` varchar(64) NOT NULL default '',
  `comment` longtext NOT NULL,
  `hostname` varchar(128) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  `status` tinyint(3) unsigned NOT NULL default '0',
  `format` smallint(6) NOT NULL default '0',
  `thread` varchar(255) NOT NULL,
  `name` varchar(60) default NULL,
  `mail` varchar(64) default NULL,
  `homepage` varchar(255) default NULL,
  PRIMARY KEY  (`cid`),
  KEY `pid` (`pid`),
  KEY `nid` (`nid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `files` (
  `fid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL default '0',
  `filename` varchar(255) NOT NULL default '',
  `filepath` varchar(255) NOT NULL default '',
  `filemime` varchar(255) NOT NULL default '',
  `filesize` int(10) unsigned NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `timestamp` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`fid`),
  KEY `uid` (`uid`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_formats`
--

DROP TABLE IF EXISTS `filter_formats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `filter_formats` (
  `format` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `roles` varchar(255) NOT NULL default '',
  `cache` tinyint(4) NOT NULL default '0',
  `weight` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`format`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `filter_formats`
--

LOCK TABLES `filter_formats` WRITE;
/*!40000 ALTER TABLE `filter_formats` DISABLE KEYS */;
INSERT INTO `filter_formats` (`format`, `name`, `roles`, `cache`, `weight`) VALUES (1,'Filtered HTML',',1,2,',1,0),(2,'Full HTML','',1,0);
/*!40000 ALTER TABLE `filter_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `filters` (
  `fid` int(11) NOT NULL auto_increment,
  `format` int(11) NOT NULL default '0',
  `module` varchar(64) NOT NULL default '',
  `delta` tinyint(4) NOT NULL default '0',
  `weight` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`fid`),
  UNIQUE KEY `fmd` (`format`,`module`,`delta`),
  KEY `list` (`format`,`weight`,`module`,`delta`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` (`fid`, `format`, `module`, `delta`, `weight`) VALUES (1,1,'filter',2,0),(2,1,'filter',0,1),(3,1,'filter',1,2),(4,1,'filter',3,10),(5,2,'filter',2,0),(6,2,'filter',1,1),(7,2,'filter',3,10);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flood`
--

DROP TABLE IF EXISTS `flood`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `flood` (
  `fid` int(11) NOT NULL auto_increment,
  `event` varchar(64) NOT NULL default '',
  `hostname` varchar(128) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`fid`),
  KEY `allow` (`event`,`hostname`,`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `flood`
--

LOCK TABLES `flood` WRITE;
/*!40000 ALTER TABLE `flood` DISABLE KEYS */;
/*!40000 ALTER TABLE `flood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `history` (
  `uid` int(11) NOT NULL default '0',
  `nid` int(11) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`uid`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_custom`
--

DROP TABLE IF EXISTS `menu_custom`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `menu_custom` (
  `menu_name` varchar(32) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `description` text,
  PRIMARY KEY  (`menu_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `menu_custom`
--

LOCK TABLES `menu_custom` WRITE;
/*!40000 ALTER TABLE `menu_custom` DISABLE KEYS */;
INSERT INTO `menu_custom` (`menu_name`, `title`, `description`) VALUES ('navigation','Navigation','The navigation menu is provided by Drupal and is the main interactive menu for any site. It is usually the only menu that contains personalized links for authenticated users, and is often not even visible to anonymous users.'),('primary-links','Primary links','Primary links are often used at the theme layer to show the major sections of a site. A typical representation for primary links would be tabs along the top.'),('secondary-links','Secondary links','Secondary links are often used for pages like legal notices, contact details, and other secondary navigation items that play a lesser role than primary links.');
/*!40000 ALTER TABLE `menu_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_links`
--

DROP TABLE IF EXISTS `menu_links`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `menu_links` (
  `menu_name` varchar(32) NOT NULL default '',
  `mlid` int(10) unsigned NOT NULL auto_increment,
  `plid` int(10) unsigned NOT NULL default '0',
  `link_path` varchar(255) NOT NULL default '',
  `router_path` varchar(255) NOT NULL default '',
  `link_title` varchar(255) NOT NULL default '',
  `options` text,
  `module` varchar(255) NOT NULL default 'system',
  `hidden` smallint(6) NOT NULL default '0',
  `external` smallint(6) NOT NULL default '0',
  `has_children` smallint(6) NOT NULL default '0',
  `expanded` smallint(6) NOT NULL default '0',
  `weight` int(11) NOT NULL default '0',
  `depth` smallint(6) NOT NULL default '0',
  `customized` smallint(6) NOT NULL default '0',
  `p1` int(10) unsigned NOT NULL default '0',
  `p2` int(10) unsigned NOT NULL default '0',
  `p3` int(10) unsigned NOT NULL default '0',
  `p4` int(10) unsigned NOT NULL default '0',
  `p5` int(10) unsigned NOT NULL default '0',
  `p6` int(10) unsigned NOT NULL default '0',
  `p7` int(10) unsigned NOT NULL default '0',
  `p8` int(10) unsigned NOT NULL default '0',
  `p9` int(10) unsigned NOT NULL default '0',
  `updated` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`mlid`),
  KEY `path_menu` (`link_path`(128),`menu_name`),
  KEY `menu_plid_expand_child` (`menu_name`,`plid`,`expanded`,`has_children`),
  KEY `menu_parents` (`menu_name`,`p1`,`p2`,`p3`,`p4`,`p5`,`p6`,`p7`,`p8`,`p9`),
  KEY `router_path` (`router_path`(128))
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `menu_links`
--

LOCK TABLES `menu_links` WRITE;
/*!40000 ALTER TABLE `menu_links` DISABLE KEYS */;
INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES ('navigation',1,0,'batch','batch','','a:0:{}','system',-1,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0),('navigation',2,0,'admin','admin','Administer','a:0:{}','system',0,0,1,0,9,1,0,2,0,0,0,0,0,0,0,0,0),('navigation',3,0,'node','node','Content','a:0:{}','system',-1,0,0,0,0,1,0,3,0,0,0,0,0,0,0,0,0),('navigation',4,0,'logout','logout','Log out','a:0:{}','system',0,0,0,0,10,1,0,4,0,0,0,0,0,0,0,0,0),('navigation',5,0,'rss.xml','rss.xml','RSS feed','a:0:{}','system',-1,0,0,0,0,1,0,5,0,0,0,0,0,0,0,0,0),('navigation',6,0,'user','user','User account','a:0:{}','system',-1,0,0,0,0,1,0,6,0,0,0,0,0,0,0,0,0),('navigation',7,0,'node/%','node/%','','a:0:{}','system',-1,0,0,0,0,1,0,7,0,0,0,0,0,0,0,0,0),('navigation',8,2,'admin/compact','admin/compact','Compact mode','a:0:{}','system',-1,0,0,0,0,2,0,2,8,0,0,0,0,0,0,0,0),('navigation',9,0,'filter/tips','filter/tips','Compose tips','a:0:{}','system',1,0,0,0,0,1,0,9,0,0,0,0,0,0,0,0,0),('navigation',10,2,'admin/content','admin/content','Content management','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:27:\"Manage your site\'s content.\";}}','system',0,0,1,0,-10,2,0,2,10,0,0,0,0,0,0,0,0),('navigation',11,0,'node/add','node/add','Create content','a:0:{}','system',0,0,1,0,1,1,0,11,0,0,0,0,0,0,0,0,0),('navigation',12,0,'comment/delete','comment/delete','Delete comment','a:0:{}','system',-1,0,0,0,0,1,0,12,0,0,0,0,0,0,0,0,0),('navigation',13,0,'comment/edit','comment/edit','Edit comment','a:0:{}','system',-1,0,0,0,0,1,0,13,0,0,0,0,0,0,0,0,0),('navigation',14,0,'system/files','system/files','File download','a:0:{}','system',-1,0,0,0,0,1,0,14,0,0,0,0,0,0,0,0,0),('navigation',15,2,'admin/help','admin/help','Help','a:0:{}','system',0,0,0,0,9,2,0,2,15,0,0,0,0,0,0,0,0),('navigation',16,2,'admin/reports','admin/reports','Reports','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:59:\"View reports from system logs and other status information.\";}}','system',0,0,1,0,5,2,0,2,16,0,0,0,0,0,0,0,0),('navigation',17,2,'admin/build','admin/build','Site building','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:38:\"Control how your site looks and feels.\";}}','system',0,0,1,0,-10,2,0,2,17,0,0,0,0,0,0,0,0),('navigation',18,2,'admin/settings','admin/settings','Site configuration','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:40:\"Adjust basic site configuration options.\";}}','system',0,0,1,0,-5,2,0,2,18,0,0,0,0,0,0,0,0),('navigation',19,0,'user/autocomplete','user/autocomplete','User autocomplete','a:0:{}','system',-1,0,0,0,0,1,0,19,0,0,0,0,0,0,0,0,0),('navigation',20,2,'admin/user','admin/user','User management','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:61:\"Manage your site\'s users, groups and access to site features.\";}}','system',0,0,1,0,0,2,0,2,20,0,0,0,0,0,0,0,0),('navigation',21,0,'user/%','user/%','My account','a:0:{}','system',0,0,0,0,0,1,0,21,0,0,0,0,0,0,0,0,0),('navigation',22,18,'admin/settings/actions','admin/settings/actions','Actions','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:41:\"Manage the actions defined for your site.\";}}','system',0,0,0,0,0,3,0,2,18,22,0,0,0,0,0,0,0),('navigation',23,18,'admin/settings/admin','admin/settings/admin','Administration theme','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:55:\"Settings for how your administrative pages should look.\";}}','system',0,0,0,0,0,3,0,2,18,23,0,0,0,0,0,0,0),('navigation',24,17,'admin/build/block','admin/build/block','Blocks','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:79:\"Configure what block content appears in your site\'s sidebars and other regions.\";}}','system',0,0,0,0,0,3,0,2,17,24,0,0,0,0,0,0,0),('navigation',25,18,'admin/settings/clean-urls','admin/settings/clean-urls','Clean URLs','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"Enable or disable clean URLs for your site.\";}}','system',0,0,0,0,0,3,0,2,18,25,0,0,0,0,0,0,0),('navigation',26,10,'admin/content/comment','admin/content/comment','Comments','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:61:\"List and edit site comments and the comment moderation queue.\";}}','system',0,0,0,0,0,3,0,2,10,26,0,0,0,0,0,0,0),('navigation',27,10,'admin/content/node','admin/content/node','Content','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"View, edit, and delete your site\'s content.\";}}','system',0,0,0,0,0,3,0,2,10,27,0,0,0,0,0,0,0),('navigation',28,17,'admin/build/types','admin/build/types','Content types','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:82:\"Manage posts by content type, including default status, front page promotion, etc.\";}}','system',0,0,0,0,0,3,0,2,17,28,0,0,0,0,0,0,0),('navigation',29,18,'admin/settings/date-time','admin/settings/date-time','Date and time','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:89:\"Settings for how Drupal displays date and time, as well as the system\'s default timezone.\";}}','system',0,0,0,0,0,3,0,2,18,29,0,0,0,0,0,0,0),('navigation',30,0,'node/%/delete','node/%/delete','Delete','a:0:{}','system',-1,0,0,0,1,1,0,30,0,0,0,0,0,0,0,0,0),('navigation',31,21,'user/%/delete','user/%/delete','Delete','a:0:{}','system',-1,0,0,0,0,2,0,21,31,0,0,0,0,0,0,0,0),('navigation',32,18,'admin/settings/error-reporting','admin/settings/error-reporting','Error reporting','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:93:\"Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.\";}}','system',0,0,0,0,0,3,0,2,18,32,0,0,0,0,0,0,0),('navigation',33,18,'admin/settings/file-system','admin/settings/file-system','File system','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:68:\"Tell Drupal where to store uploaded files and how they are accessed.\";}}','system',0,0,0,0,0,3,0,2,18,33,0,0,0,0,0,0,0),('navigation',34,18,'admin/settings/ip-blocking','admin/settings/ip-blocking','IP address blocking','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:28:\"Manage blocked IP addresses.\";}}','system',0,0,0,0,0,3,0,2,18,34,0,0,0,0,0,0,0),('navigation',35,18,'admin/settings/image-toolkit','admin/settings/image-toolkit','Image toolkit','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:74:\"Choose which image toolkit to use if you have installed optional toolkits.\";}}','system',0,0,0,0,0,3,0,2,18,35,0,0,0,0,0,0,0),('navigation',36,18,'admin/settings/filters','admin/settings/filters','Input formats','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:127:\"Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.\";}}','system',0,0,0,0,0,3,0,2,18,36,0,0,0,0,0,0,0),('navigation',37,18,'admin/settings/logging','admin/settings/logging','Logging and alerts','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:156:\"Settings for logging and alerts modules. Various modules can route Drupal\'s system events to different destination, such as syslog, database, email, ...etc.\";}}','system',0,0,1,0,0,3,0,2,18,37,0,0,0,0,0,0,0),('navigation',38,17,'admin/build/menu','admin/build/menu','Menus','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:116:\"Control your site\'s navigation menu, primary links and secondary links. as well as rename and reorganize menu items.\";}}','system',0,0,1,0,0,3,0,2,17,38,0,0,0,0,0,0,0),('navigation',39,17,'admin/build/modules','admin/build/modules','Modules','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:47:\"Enable or disable add-on modules for your site.\";}}','system',0,0,0,0,0,3,0,2,17,39,0,0,0,0,0,0,0),('navigation',40,18,'admin/settings/performance','admin/settings/performance','Performance','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:101:\"Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.\";}}','system',0,0,0,0,0,3,0,2,18,40,0,0,0,0,0,0,0),('navigation',41,20,'admin/user/permissions','admin/user/permissions','Permissions','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:64:\"Determine access to features by selecting permissions for roles.\";}}','system',0,0,0,0,0,3,0,2,20,41,0,0,0,0,0,0,0),('navigation',42,10,'admin/content/node-settings','admin/content/node-settings','Post settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:126:\"Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.\";}}','system',0,0,0,0,0,3,0,2,10,42,0,0,0,0,0,0,0),('navigation',43,10,'admin/content/rss-publishing','admin/content/rss-publishing','RSS publishing','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:92:\"Configure the number of items per feed and whether feeds should be titles/teasers/full-text.\";}}','system',0,0,0,0,0,3,0,2,10,43,0,0,0,0,0,0,0),('navigation',44,0,'comment/reply/%','comment/reply/%','Reply to comment','a:0:{}','system',-1,0,0,0,0,1,0,44,0,0,0,0,0,0,0,0,0),('navigation',45,16,'admin/reports/request-test','admin/reports/request-test','Request test','a:0:{}','system',-1,0,0,0,0,3,0,2,16,45,0,0,0,0,0,0,0),('navigation',46,20,'admin/user/roles','admin/user/roles','Roles','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:30:\"List, edit, or add user roles.\";}}','system',0,0,0,0,0,3,0,2,20,46,0,0,0,0,0,0,0),('navigation',47,18,'admin/settings/site-information','admin/settings/site-information','Site information','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:107:\"Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.\";}}','system',0,0,0,0,0,3,0,2,18,47,0,0,0,0,0,0,0),('navigation',48,18,'admin/settings/site-maintenance','admin/settings/site-maintenance','Site maintenance','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:63:\"Take the site off-line for maintenance or bring it back online.\";}}','system',0,0,0,0,0,3,0,2,18,48,0,0,0,0,0,0,0),('navigation',49,16,'admin/reports/status','admin/reports/status','Status report','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:74:\"Get a status report about your site\'s operation and any detected problems.\";}}','system',0,0,0,0,10,3,0,2,16,49,0,0,0,0,0,0,0),('navigation',50,17,'admin/build/themes','admin/build/themes','Themes','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:57:\"Change which theme your site uses or allows users to set.\";}}','system',0,0,0,0,0,3,0,2,17,50,0,0,0,0,0,0,0),('navigation',51,20,'admin/user/settings','admin/user/settings','User settings','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:101:\"Configure default behavior of users, including registration requirements, e-mails, and user pictures.\";}}','system',0,0,0,0,0,3,0,2,20,51,0,0,0,0,0,0,0),('navigation',52,20,'admin/user/user','admin/user/user','Users','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:26:\"List, add, and edit users.\";}}','system',0,0,0,0,0,3,0,2,20,52,0,0,0,0,0,0,0),('navigation',53,15,'admin/help/block','admin/help/block','block','a:0:{}','system',-1,0,0,0,0,3,0,2,15,53,0,0,0,0,0,0,0),('navigation',54,15,'admin/help/color','admin/help/color','color','a:0:{}','system',-1,0,0,0,0,3,0,2,15,54,0,0,0,0,0,0,0),('navigation',55,15,'admin/help/comment','admin/help/comment','comment','a:0:{}','system',-1,0,0,0,0,3,0,2,15,55,0,0,0,0,0,0,0),('navigation',56,15,'admin/help/filter','admin/help/filter','filter','a:0:{}','system',-1,0,0,0,0,3,0,2,15,56,0,0,0,0,0,0,0),('navigation',57,15,'admin/help/help','admin/help/help','help','a:0:{}','system',-1,0,0,0,0,3,0,2,15,57,0,0,0,0,0,0,0),('navigation',58,15,'admin/help/menu','admin/help/menu','menu','a:0:{}','system',-1,0,0,0,0,3,0,2,15,58,0,0,0,0,0,0,0),('navigation',59,15,'admin/help/node','admin/help/node','node','a:0:{}','system',-1,0,0,0,0,3,0,2,15,59,0,0,0,0,0,0,0),('navigation',60,15,'admin/help/system','admin/help/system','system','a:0:{}','system',-1,0,0,0,0,3,0,2,15,60,0,0,0,0,0,0,0),('navigation',61,15,'admin/help/user','admin/help/user','user','a:0:{}','system',-1,0,0,0,0,3,0,2,15,61,0,0,0,0,0,0,0),('navigation',62,36,'admin/settings/filters/%','admin/settings/filters/%','','a:0:{}','system',-1,0,0,0,0,4,0,2,18,36,62,0,0,0,0,0,0),('navigation',63,25,'admin/settings/clean-urls/check','admin/settings/clean-urls/check','Clean URL check','a:0:{}','system',-1,0,0,0,0,4,0,2,18,25,63,0,0,0,0,0,0),('navigation',64,22,'admin/settings/actions/configure','admin/settings/actions/configure','Configure an advanced action','a:0:{}','system',-1,0,0,0,0,4,0,2,18,22,64,0,0,0,0,0,0),('navigation',65,24,'admin/build/block/configure','admin/build/block/configure','Configure block','a:0:{}','system',-1,0,0,0,0,4,0,2,17,24,65,0,0,0,0,0,0),('navigation',66,17,'admin/build/menu-customize/%','admin/build/menu-customize/%','Customize menu','a:0:{}','system',-1,0,0,0,0,3,0,2,17,66,0,0,0,0,0,0,0),('navigation',67,29,'admin/settings/date-time/lookup','admin/settings/date-time/lookup','Date and time lookup','a:0:{}','system',-1,0,0,0,0,4,0,2,18,29,67,0,0,0,0,0,0),('navigation',68,24,'admin/build/block/delete','admin/build/block/delete','Delete block','a:0:{}','system',-1,0,0,0,0,4,0,2,17,24,68,0,0,0,0,0,0),('navigation',69,36,'admin/settings/filters/delete','admin/settings/filters/delete','Delete input format','a:0:{}','system',-1,0,0,0,0,4,0,2,18,36,69,0,0,0,0,0,0),('navigation',70,46,'admin/user/roles/edit','admin/user/roles/edit','Edit role','a:0:{}','system',-1,0,0,0,0,4,0,2,20,46,70,0,0,0,0,0,0),('navigation',71,34,'admin/settings/ip-blocking/%','admin/settings/ip-blocking/%','IP address blocking','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:28:\"Manage blocked IP addresses.\";}}','system',-1,0,0,0,0,4,0,2,18,34,71,0,0,0,0,0,0),('navigation',72,49,'admin/reports/status/php','admin/reports/status/php','PHP','a:0:{}','system',-1,0,0,0,0,4,0,2,16,49,72,0,0,0,0,0,0),('navigation',73,42,'admin/content/node-settings/rebuild','admin/content/node-settings/rebuild','Rebuild permissions','a:0:{}','system',-1,0,0,0,0,4,0,2,10,42,73,0,0,0,0,0,0),('navigation',74,22,'admin/settings/actions/orphan','admin/settings/actions/orphan','Remove orphans','a:0:{}','system',-1,0,0,0,0,4,0,2,18,22,74,0,0,0,0,0,0),('navigation',75,49,'admin/reports/status/run-cron','admin/reports/status/run-cron','Run cron','a:0:{}','system',-1,0,0,0,0,4,0,2,16,49,75,0,0,0,0,0,0),('navigation',76,49,'admin/reports/status/sql','admin/reports/status/sql','SQL','a:0:{}','system',-1,0,0,0,0,4,0,2,16,49,76,0,0,0,0,0,0),('navigation',77,34,'admin/settings/ip-blocking/delete/%','admin/settings/ip-blocking/delete/%','Delete IP address','a:0:{}','system',-1,0,0,0,0,4,0,2,18,34,77,0,0,0,0,0,0),('navigation',78,22,'admin/settings/actions/delete/%','admin/settings/actions/delete/%','Delete action','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:17:\"Delete an action.\";}}','system',-1,0,0,0,0,4,0,2,18,22,78,0,0,0,0,0,0),('navigation',79,0,'admin/build/menu-customize/%/delete','admin/build/menu-customize/%/delete','Delete menu','a:0:{}','system',-1,0,0,0,0,1,0,79,0,0,0,0,0,0,0,0,0),('navigation',80,24,'admin/build/block/list/js','admin/build/block/list/js','JavaScript List Form','a:0:{}','system',-1,0,0,0,0,4,0,2,17,24,80,0,0,0,0,0,0),('navigation',81,39,'admin/build/modules/list/confirm','admin/build/modules/list/confirm','List','a:0:{}','system',-1,0,0,0,0,4,0,2,17,39,81,0,0,0,0,0,0),('navigation',82,0,'user/reset/%/%/%','user/reset/%/%/%','Reset password','a:0:{}','system',-1,0,0,0,0,1,0,82,0,0,0,0,0,0,0,0,0),('navigation',83,39,'admin/build/modules/uninstall/confirm','admin/build/modules/uninstall/confirm','Uninstall','a:0:{}','system',-1,0,0,0,0,4,0,2,17,39,83,0,0,0,0,0,0),('navigation',84,0,'node/%/revisions/%/delete','node/%/revisions/%/delete','Delete earlier revision','a:0:{}','system',-1,0,0,0,0,1,0,84,0,0,0,0,0,0,0,0,0),('navigation',85,0,'node/%/revisions/%/revert','node/%/revisions/%/revert','Revert to earlier revision','a:0:{}','system',-1,0,0,0,0,1,0,85,0,0,0,0,0,0,0,0,0),('navigation',86,0,'node/%/revisions/%/view','node/%/revisions/%/view','Revisions','a:0:{}','system',-1,0,0,0,0,1,0,86,0,0,0,0,0,0,0,0,0),('navigation',87,38,'admin/build/menu/item/%/delete','admin/build/menu/item/%/delete','Delete menu item','a:0:{}','system',-1,0,0,0,0,4,0,2,17,38,87,0,0,0,0,0,0),('navigation',88,38,'admin/build/menu/item/%/edit','admin/build/menu/item/%/edit','Edit menu item','a:0:{}','system',-1,0,0,0,0,4,0,2,17,38,88,0,0,0,0,0,0),('navigation',89,38,'admin/build/menu/item/%/reset','admin/build/menu/item/%/reset','Reset menu item','a:0:{}','system',-1,0,0,0,0,4,0,2,17,38,89,0,0,0,0,0,0),('navigation',90,38,'admin/build/menu-customize/navigation','admin/build/menu-customize/%','Navigation','a:0:{}','menu',0,0,0,0,0,4,0,2,17,38,90,0,0,0,0,0,0),('navigation',91,38,'admin/build/menu-customize/primary-links','admin/build/menu-customize/%','Primary links','a:0:{}','menu',0,0,0,0,0,4,0,2,17,38,91,0,0,0,0,0,0),('navigation',92,38,'admin/build/menu-customize/secondary-links','admin/build/menu-customize/%','Secondary links','a:0:{}','menu',0,0,0,0,0,4,0,2,17,38,92,0,0,0,0,0,0),('navigation',93,0,'taxonomy/autocomplete','taxonomy/autocomplete','Autocomplete taxonomy','a:0:{}','system',-1,0,0,0,0,1,0,93,0,0,0,0,0,0,0,0,0),('navigation',94,16,'admin/reports/dblog','admin/reports/dblog','Recent log entries','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:43:\"View events that have recently been logged.\";}}','system',0,0,0,0,-1,3,0,2,16,94,0,0,0,0,0,0,0),('navigation',95,10,'admin/content/taxonomy','admin/content/taxonomy','Taxonomy','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:67:\"Manage tagging, categorization, and classification of your content.\";}}','system',0,0,0,0,0,3,0,2,10,95,0,0,0,0,0,0,0),('navigation',96,0,'taxonomy/term/%','taxonomy/term/%','Taxonomy term','a:0:{}','system',-1,0,0,0,0,1,0,96,0,0,0,0,0,0,0,0,0),('navigation',97,16,'admin/reports/access-denied','admin/reports/access-denied','Top \'access denied\' errors','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:35:\"View \'access denied\' errors (403s).\";}}','system',0,0,0,0,0,3,0,2,16,97,0,0,0,0,0,0,0),('navigation',98,16,'admin/reports/page-not-found','admin/reports/page-not-found','Top \'page not found\' errors','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:36:\"View \'page not found\' errors (404s).\";}}','system',0,0,0,0,0,3,0,2,16,98,0,0,0,0,0,0,0),('navigation',99,15,'admin/help/dblog','admin/help/dblog','dblog','a:0:{}','system',-1,0,0,0,0,3,0,2,15,99,0,0,0,0,0,0,0),('navigation',100,15,'admin/help/taxonomy','admin/help/taxonomy','taxonomy','a:0:{}','system',-1,0,0,0,0,3,0,2,15,100,0,0,0,0,0,0,0),('navigation',101,37,'admin/settings/logging/dblog','admin/settings/logging/dblog','Database logging','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:169:\"Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.\";}}','system',0,0,0,0,0,4,0,2,18,37,101,0,0,0,0,0,0),('navigation',102,16,'admin/reports/event/%','admin/reports/event/%','Details','a:0:{}','system',-1,0,0,0,0,3,0,2,16,102,0,0,0,0,0,0,0),('navigation',103,95,'admin/content/taxonomy/%','admin/content/taxonomy/%','List terms','a:0:{}','system',-1,0,0,0,0,4,0,2,10,95,103,0,0,0,0,0,0),('navigation',104,95,'admin/content/taxonomy/edit/term','admin/content/taxonomy/edit/term','Edit term','a:0:{}','system',-1,0,0,0,0,4,0,2,10,95,104,0,0,0,0,0,0),('navigation',105,95,'admin/content/taxonomy/edit/vocabulary/%','admin/content/taxonomy/edit/vocabulary/%','Edit vocabulary','a:0:{}','system',-1,0,0,0,0,4,0,2,10,95,105,0,0,0,0,0,0),('navigation',106,11,'node/add/article','node/add/article','Article','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:401:\"An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.\";}}','system',0,0,0,0,0,2,0,11,106,0,0,0,0,0,0,0,0),('navigation',107,11,'node/add/page','node/add/page','Page','a:1:{s:10:\"attributes\";a:1:{s:5:\"title\";s:299:\"A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";}}','system',0,0,0,0,0,2,0,11,107,0,0,0,0,0,0,0,0),('navigation',108,17,'admin/build/node-type/article','admin/build/node-type/article','Article','a:0:{}','system',-1,0,0,0,0,3,0,2,17,108,0,0,0,0,0,0,0),('navigation',109,17,'admin/build/node-type/page','admin/build/node-type/page','Page','a:0:{}','system',-1,0,0,0,0,3,0,2,17,109,0,0,0,0,0,0,0),('navigation',110,0,'admin/build/node-type/article/delete','admin/build/node-type/article/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,110,0,0,0,0,0,0,0,0,0),('navigation',111,0,'admin/build/node-type/page/delete','admin/build/node-type/page/delete','Delete','a:0:{}','system',-1,0,0,0,0,1,0,111,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `menu_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_router`
--

DROP TABLE IF EXISTS `menu_router`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `menu_router` (
  `path` varchar(255) NOT NULL default '',
  `load_functions` varchar(255) NOT NULL default '',
  `to_arg_functions` varchar(255) NOT NULL default '',
  `access_callback` varchar(255) NOT NULL default '',
  `access_arguments` text,
  `page_callback` varchar(255) NOT NULL default '',
  `page_arguments` text,
  `fit` int(11) NOT NULL default '0',
  `number_parts` smallint(6) NOT NULL default '0',
  `tab_parent` varchar(255) NOT NULL default '',
  `tab_root` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `title_callback` varchar(255) NOT NULL default '',
  `title_arguments` varchar(255) NOT NULL default '',
  `type` int(11) NOT NULL default '0',
  `block_callback` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `position` varchar(255) NOT NULL default '',
  `weight` int(11) NOT NULL default '0',
  PRIMARY KEY  (`path`),
  KEY `fit` (`fit`),
  KEY `tab_parent` (`tab_parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `menu_router`
--

LOCK TABLES `menu_router` WRITE;
/*!40000 ALTER TABLE `menu_router` DISABLE KEYS */;
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `fit`, `number_parts`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `type`, `block_callback`, `description`, `position`, `weight`) VALUES ('batch','','','1','a:0:{}','system_batch_page','a:0:{}',1,1,'','batch','','t','',4,'','','',0),('admin','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_main_admin_page','a:0:{}',1,1,'','admin','Administer','t','',6,'','','',9),('node','','','user_access','a:1:{i:0;s:14:\"access content\";}','node_page_default','a:0:{}',1,1,'','node','Content','t','',4,'','','',0),('logout','','','user_is_logged_in','a:0:{}','user_logout','a:0:{}',1,1,'','logout','Log out','t','',6,'','','',10),('rss.xml','','','user_access','a:1:{i:0;s:14:\"access content\";}','node_feed','a:0:{}',1,1,'','rss.xml','RSS feed','t','',4,'','','',0),('user','','','1','a:0:{}','user_page','a:0:{}',1,1,'','user','User account','t','',4,'','','',0),('user/login','','','user_is_anonymous','a:0:{}','user_page','a:0:{}',3,2,'user','user','Log in','t','',136,'','','',0),('taxonomy/autocomplete','','','user_access','a:1:{i:0;s:14:\"access content\";}','taxonomy_autocomplete','a:0:{}',3,2,'','taxonomy/autocomplete','Autocomplete taxonomy','t','',4,'','','',0),('admin/by-module','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_by_module','a:0:{}',3,2,'admin','admin','By module','t','',128,'','','',2),('admin/by-task','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_main_admin_page','a:0:{}',3,2,'admin','admin','By task','t','',136,'','','',0),('admin/compact','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_compact_page','a:0:{}',3,2,'','admin/compact','Compact mode','t','',4,'','','',0),('filter/tips','','','1','a:0:{}','filter_tips_long','a:0:{}',3,2,'','filter/tips','Compose tips','t','',20,'','','',0),('node/add','','','_node_add_access','a:0:{}','node_add_page','a:0:{}',3,2,'','node/add','Create content','t','',6,'','','',1),('comment/delete','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_delete','a:0:{}',3,2,'','comment/delete','Delete comment','t','',4,'','','',0),('comment/edit','','','user_access','a:1:{i:0;s:13:\"post comments\";}','comment_edit','a:0:{}',3,2,'','comment/edit','Edit comment','t','',4,'','','',0),('system/files','','','1','a:0:{}','file_download','a:0:{}',3,2,'','system/files','File download','t','',4,'','','',0),('admin/help','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_main','a:0:{}',3,2,'','admin/help','Help','t','',6,'','','',9),('user/register','','','user_register_access','a:0:{}','drupal_get_form','a:1:{i:0;s:13:\"user_register\";}',3,2,'user','user','Create new account','t','',128,'','','',0),('user/password','','','user_is_anonymous','a:0:{}','drupal_get_form','a:1:{i:0;s:9:\"user_pass\";}',3,2,'user','user','Request new password','t','',128,'','','',0),('user/autocomplete','','','user_access','a:1:{i:0;s:20:\"access user profiles\";}','user_autocomplete','a:0:{}',3,2,'','user/autocomplete','User autocomplete','t','',4,'','','',0),('admin/content','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/content','Content management','t','',6,'','Manage your site\'s content.','left',-10),('admin/reports','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/reports','Reports','t','',6,'','View reports from system logs and other status information.','left',5),('admin/build','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/build','Site building','t','',6,'','Control how your site looks and feels.','right',-10),('admin/settings','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_settings_overview','a:0:{}',3,2,'','admin/settings','Site configuration','t','',6,'','Adjust basic site configuration options.','right',-5),('admin/user','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','system_admin_menu_block_page','a:0:{}',3,2,'','admin/user','User management','t','',6,'','Manage your site\'s users, groups and access to site features.','left',0),('node/%','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:1;}','node_page_view','a:1:{i:0;i:1;}',2,2,'','node/%','','node_page_title','a:1:{i:0;i:1;}',4,'','','',0),('user/%','a:1:{i:1;s:22:\"user_uid_optional_load\";}','a:1:{i:1;s:24:\"user_uid_optional_to_arg\";}','user_view_access','a:1:{i:0;i:1;}','user_view','a:1:{i:0;i:1;}',2,2,'','user/%','My account','user_page_title','a:1:{i:0;i:1;}',6,'','','',0),('node/%/view','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:1;}','node_page_view','a:1:{i:0;i:1;}',5,3,'node/%','node/%','View','t','',136,'','','',-10),('user/%/view','a:1:{i:1;s:9:\"user_load\";}','','user_view_access','a:1:{i:0;i:1;}','user_view','a:1:{i:0;i:1;}',5,3,'user/%','user/%','View','t','',136,'','','',-10),('admin/settings/actions','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_manage','a:0:{}',7,3,'','admin/settings/actions','Actions','t','',6,'','Manage the actions defined for your site.','',0),('admin/build/block','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display','a:0:{}',7,3,'','admin/build/block','Blocks','t','',6,'','Configure what block content appears in your site\'s sidebars and other regions.','',0),('admin/content/comment','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:0:{}',7,3,'','admin/content/comment','Comments','t','',6,'','List and edit site comments and the comment moderation queue.','',0),('admin/build/types','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','node_overview_types','a:0:{}',7,3,'','admin/build/types','Content types','t','',6,'','Manage posts by content type, including default status, front page promotion, etc.','',0),('admin/settings/ip-blocking','','','user_access','a:1:{i:0;s:18:\"block IP addresses\";}','system_ip_blocking','a:0:{}',7,3,'','admin/settings/ip-blocking','IP address blocking','t','',6,'','Manage blocked IP addresses.','',0),('admin/settings/logging','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_logging_overview','a:0:{}',7,3,'','admin/settings/logging','Logging and alerts','t','',6,'','Settings for logging and alerts modules. Various modules can route Drupal\'s system events to different destination, such as syslog, database, email, ...etc.','',0),('admin/reports/dblog','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_overview','a:0:{}',7,3,'','admin/reports/dblog','Recent log entries','t','',6,'','View events that have recently been logged.','',-1),('admin/reports/request-test','','','1','a:0:{}','printf','a:1:{i:0;s:12:\"request test\";}',7,3,'','admin/reports/request-test','Request test','t','',4,'','','',0),('admin/reports/status','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_status','a:0:{}',7,3,'','admin/reports/status','Status report','t','',6,'','Get a status report about your site\'s operation and any detected problems.','',10),('taxonomy/term/%','a:1:{i:2;N;}','','user_access','a:1:{i:0;s:14:\"access content\";}','taxonomy_term_page','a:1:{i:0;i:2;}',6,3,'','taxonomy/term/%','Taxonomy term','t','',4,'','','',0),('admin/help/block','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/block','block','t','',4,'','','',0),('admin/help/color','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/color','color','t','',4,'','','',0),('admin/help/comment','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/comment','comment','t','',4,'','','',0),('admin/help/dblog','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/dblog','dblog','t','',4,'','','',0),('admin/help/filter','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/filter','filter','t','',4,'','','',0),('admin/help/help','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/help','help','t','',4,'','','',0),('admin/help/menu','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/menu','menu','t','',4,'','','',0),('admin/help/node','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/node','node','t','',4,'','','',0),('admin/help/system','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/system','system','t','',4,'','','',0),('admin/help/taxonomy','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/taxonomy','taxonomy','t','',4,'','','',0),('admin/help/user','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','help_page','a:1:{i:0;i:2;}',7,3,'','admin/help/user','user','t','',4,'','','',0),('admin/settings/clean-urls','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_clean_url_settings\";}',7,3,'','admin/settings/clean-urls','Clean URLs','t','',6,'','Enable or disable clean URLs for your site.','',0),('admin/content/node','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:18:\"node_admin_content\";}',7,3,'','admin/content/node','Content','t','',6,'','View, edit, and delete your site\'s content.','',0),('admin/settings/date-time','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_date_time_settings\";}',7,3,'','admin/settings/date-time','Date and time','t','',6,'','Settings for how Drupal displays date and time, as well as the system\'s default timezone.','',0),('node/%/delete','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:6:\"delete\";i:1;i:1;}','drupal_get_form','a:2:{i:0;s:19:\"node_delete_confirm\";i:1;i:1;}',5,3,'','node/%/delete','Delete','t','',4,'','','',1),('user/%/delete','a:1:{i:1;s:9:\"user_load\";}','','user_access','a:1:{i:0;s:16:\"administer users\";}','drupal_get_form','a:2:{i:0;s:19:\"user_confirm_delete\";i:1;i:1;}',5,3,'','user/%/delete','Delete','t','',4,'','','',0),('node/%/edit','a:1:{i:1;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:6:\"update\";i:1;i:1;}','node_page_edit','a:1:{i:0;i:1;}',5,3,'node/%','node/%','Edit','t','',128,'','','',1),('admin/settings/error-reporting','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:31:\"system_error_reporting_settings\";}',7,3,'','admin/settings/error-reporting','Error reporting','t','',6,'','Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.','',0),('admin/settings/file-system','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_file_system_settings\";}',7,3,'','admin/settings/file-system','File system','t','',6,'','Tell Drupal where to store uploaded files and how they are accessed.','',0),('admin/settings/image-toolkit','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:29:\"system_image_toolkit_settings\";}',7,3,'','admin/settings/image-toolkit','Image toolkit','t','',6,'','Choose which image toolkit to use if you have installed optional toolkits.','',0),('admin/settings/filters','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:21:\"filter_admin_overview\";}',7,3,'','admin/settings/filters','Input formats','t','',6,'','Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.','',0),('admin/build/menu','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_overview_page','a:0:{}',7,3,'','admin/build/menu','Menus','t','',6,'','Control your site\'s navigation menu, primary links and secondary links. as well as rename and reorganize menu items.','',0),('admin/build/modules','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',7,3,'','admin/build/modules','Modules','t','',6,'','Enable or disable add-on modules for your site.','',0),('admin/settings/performance','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_performance_settings\";}',7,3,'','admin/settings/performance','Performance','t','',6,'','Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.','',0),('admin/user/permissions','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:15:\"user_admin_perm\";}',7,3,'','admin/user/permissions','Permissions','t','',6,'','Determine access to features by selecting permissions for roles.','',0),('admin/content/node-settings','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:14:\"node_configure\";}',7,3,'','admin/content/node-settings','Post settings','t','',6,'','Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.','',0),('admin/content/rss-publishing','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:25:\"system_rss_feeds_settings\";}',7,3,'','admin/content/rss-publishing','RSS publishing','t','',6,'','Configure the number of items per feed and whether feeds should be titles/teasers/full-text.','',0),('comment/reply/%','a:1:{i:2;s:9:\"node_load\";}','','node_access','a:2:{i:0;s:4:\"view\";i:1;i:2;}','comment_reply','a:1:{i:0;i:2;}',6,3,'','comment/reply/%','Reply to comment','t','',4,'','','',0),('node/%/revisions','a:1:{i:1;s:9:\"node_load\";}','','_node_revision_access','a:1:{i:0;i:1;}','node_revision_overview','a:1:{i:0;i:1;}',5,3,'node/%','node/%','Revisions','t','',128,'','','',2),('admin/user/roles','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:19:\"user_admin_new_role\";}',7,3,'','admin/user/roles','Roles','t','',6,'','List, edit, or add user roles.','',0),('admin/settings/site-information','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:32:\"system_site_information_settings\";}',7,3,'','admin/settings/site-information','Site information','t','',6,'','Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.','',0),('admin/settings/site-maintenance','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:32:\"system_site_maintenance_settings\";}',7,3,'','admin/settings/site-maintenance','Site maintenance','t','',6,'','Take the site off-line for maintenance or bring it back online.','',0),('admin/content/taxonomy','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:30:\"taxonomy_overview_vocabularies\";}',7,3,'','admin/content/taxonomy','Taxonomy','t','',6,'','Manage tagging, categorization, and classification of your content.','',0),('admin/build/themes','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:18:\"system_themes_form\";i:1;N;}',7,3,'','admin/build/themes','Themes','t','',6,'','Change which theme your site uses or allows users to set.','',0),('admin/reports/access-denied','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_top','a:1:{i:0;s:13:\"access denied\";}',7,3,'','admin/reports/access-denied','Top \'access denied\' errors','t','',6,'','View \'access denied\' errors (403s).','',0),('admin/reports/page-not-found','','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_top','a:1:{i:0;s:14:\"page not found\";}',7,3,'','admin/reports/page-not-found','Top \'page not found\' errors','t','',6,'','View \'page not found\' errors (404s).','',0),('admin/user/settings','','','user_access','a:1:{i:0;s:16:\"administer users\";}','drupal_get_form','a:1:{i:0;s:19:\"user_admin_settings\";}',7,3,'','admin/user/settings','User settings','t','',6,'','Configure default behavior of users, including registration requirements, e-mails, and user pictures.','',0),('admin/user/user','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:4:\"list\";}',7,3,'','admin/user/user','Users','t','',6,'','List, add, and edit users.','',0),('user/%/edit','a:1:{i:1;a:1:{s:18:\"user_category_load\";a:2:{i:0;s:4:\"%map\";i:1;s:6:\"%index\";}}}','','user_edit_access','a:1:{i:0;i:1;}','user_edit','a:1:{i:0;i:1;}',5,3,'user/%','user/%','Edit','t','',128,'','','',0),('admin/settings/admin','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:27:\"system_admin_theme_settings\";}',7,3,'','admin/settings/admin','Administration theme','t','',6,'system_admin_theme_settings','Settings for how your administrative pages should look.','left',0),('node/add/article','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:7:\"article\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/article','Article','check_plain','',6,'','An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.','',0),('node/add/page','','','node_access','a:2:{i:0;s:6:\"create\";i:1;s:4:\"page\";}','node_add','a:1:{i:0;i:2;}',7,3,'','node/add/page','Page','check_plain','',6,'','A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.','',0),('admin/build/block/list','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display','a:0:{}',15,4,'admin/build/block','admin/build/block','List','t','',136,'','','',-10),('admin/settings/filters/list','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:21:\"filter_admin_overview\";}',15,4,'admin/settings/filters','admin/settings/filters','List','t','',136,'','','',0),('admin/build/types/list','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','node_overview_types','a:0:{}',15,4,'admin/build/types','admin/build/types','List','t','',136,'','','',-10),('admin/content/node/overview','','','user_access','a:1:{i:0;s:16:\"administer nodes\";}','drupal_get_form','a:1:{i:0;s:18:\"node_admin_content\";}',15,4,'admin/content/node','admin/content/node','List','t','',136,'','','',-10),('admin/build/modules/list','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',15,4,'admin/build/modules','admin/build/modules','List','t','',136,'','','',0),('admin/content/taxonomy/list','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:30:\"taxonomy_overview_vocabularies\";}',15,4,'admin/content/taxonomy','admin/content/taxonomy','List','t','',136,'','','',-10),('admin/user/user/list','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:4:\"list\";}',15,4,'admin/user/user','admin/user/user','List','t','',136,'','','',-10),('admin/build/menu/list','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_overview_page','a:0:{}',15,4,'admin/build/menu','admin/build/menu','List menus','t','',136,'','','',-10),('admin/content/comment/new','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:0:{}',15,4,'admin/content/comment','admin/content/comment','Published comments','t','',136,'','','',-10),('user/%/edit/account','a:1:{i:1;a:1:{s:18:\"user_category_load\";a:2:{i:0;s:4:\"%map\";i:1;s:6:\"%index\";}}}','','user_edit_access','a:1:{i:0;i:1;}','user_edit','a:1:{i:0;i:1;}',11,4,'user/%/edit','user/%','Account','t','',136,'','','',0),('admin/build/themes/select','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:2:{i:0;s:18:\"system_themes_form\";i:1;N;}',15,4,'admin/build/themes','admin/build/themes','List','t','',136,'','Select the default theme.','',-1),('admin/settings/filters/add','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:0:{}',15,4,'admin/settings/filters','admin/settings/filters','Add input format','t','',128,'','','',1),('admin/user/user/create','','','user_access','a:1:{i:0;s:16:\"administer users\";}','user_admin','a:1:{i:0;s:6:\"create\";}',15,4,'admin/user/user','admin/user/user','Add user','t','',128,'','','',0),('admin/content/comment/approval','','','user_access','a:1:{i:0;s:19:\"administer comments\";}','comment_admin','a:1:{i:0;s:8:\"approval\";}',15,4,'admin/content/comment','admin/content/comment','Approval queue','t','',128,'','','',0),('admin/build/themes/settings','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:21:\"system_theme_settings\";}',15,4,'admin/build/themes','admin/build/themes','Configure','t','',128,'','','',0),('admin/settings/date-time/lookup','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_date_time_lookup','a:0:{}',15,4,'','admin/settings/date-time/lookup','Date and time lookup','t','',4,'','','',0),('admin/user/roles/edit','','','user_access','a:1:{i:0;s:22:\"administer permissions\";}','drupal_get_form','a:1:{i:0;s:15:\"user_admin_role\";}',15,4,'','admin/user/roles/edit','Edit role','t','',4,'','','',0),('admin/settings/actions/manage','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_manage','a:0:{}',15,4,'admin/settings/actions','admin/settings/actions','Manage actions','t','',136,'','Manage the actions defined for your site.','',-2),('admin/reports/status/php','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_php','a:0:{}',15,4,'','admin/reports/status/php','PHP','t','',4,'','','',0),('admin/content/node-settings/rebuild','','','user_access','a:1:{i:0;s:27:\"access administration pages\";}','drupal_get_form','a:1:{i:0;s:30:\"node_configure_rebuild_confirm\";}',15,4,'','admin/content/node-settings/rebuild','Rebuild permissions','t','',4,'','','',0),('admin/settings/actions/orphan','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','system_actions_remove_orphans','a:0:{}',15,4,'','admin/settings/actions/orphan','Remove orphans','t','',4,'','','',0),('admin/reports/status/run-cron','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_run_cron','a:0:{}',15,4,'','admin/reports/status/run-cron','Run cron','t','',4,'','','',0),('admin/reports/status/sql','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','system_sql','a:0:{}',15,4,'','admin/reports/status/sql','SQL','t','',4,'','','',0),('admin/build/modules/uninstall','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:24:\"system_modules_uninstall\";}',15,4,'admin/build/modules','admin/build/modules','Uninstall','t','',128,'','','',0),('admin/build/block/add','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:20:\"block_add_block_form\";}',15,4,'admin/build/block','admin/build/block','Add block','t','',128,'','','',0),('admin/build/types/add','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:1:{i:0;s:14:\"node_type_form\";}',15,4,'admin/build/types','admin/build/types','Add content type','t','',128,'','','',0),('admin/build/menu/add','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:14:\"menu_edit_menu\";i:1;s:3:\"add\";}',15,4,'admin/build/menu','admin/build/menu','Add menu','t','',128,'','','',0),('admin/build/node-type/article','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"article\";s:4:\"name\";s:7:\"Article\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:401:\"An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"article\";}}',15,4,'','admin/build/node-type/article','Article','t','',4,'','','',0),('admin/settings/clean-urls/check','','','1','a:0:{}','drupal_json','a:1:{i:0;a:1:{s:6:\"status\";b:1;}}',15,4,'','admin/settings/clean-urls/check','Clean URL check','t','',4,'','','',0),('admin/settings/actions/configure','','','user_access','a:1:{i:0;s:18:\"administer actions\";}','drupal_get_form','a:1:{i:0;s:24:\"system_actions_configure\";}',15,4,'','admin/settings/actions/configure','Configure an advanced action','t','',4,'','','',0),('admin/build/block/configure','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:21:\"block_admin_configure\";}',15,4,'','admin/build/block/configure','Configure block','t','',4,'','','',0),('admin/build/block/delete','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','drupal_get_form','a:1:{i:0;s:16:\"block_box_delete\";}',15,4,'','admin/build/block/delete','Delete block','t','',4,'','','',0),('admin/settings/filters/delete','','','user_access','a:1:{i:0;s:18:\"administer filters\";}','drupal_get_form','a:1:{i:0;s:19:\"filter_admin_delete\";}',15,4,'','admin/settings/filters/delete','Delete input format','t','',4,'','','',0),('admin/reports/event/%','a:1:{i:3;N;}','','user_access','a:1:{i:0;s:19:\"access site reports\";}','dblog_event','a:1:{i:0;i:3;}',14,4,'','admin/reports/event/%','Details','t','',4,'','','',0),('admin/settings/ip-blocking/%','a:1:{i:3;N;}','','user_access','a:1:{i:0;s:18:\"block IP addresses\";}','system_ip_blocking','a:0:{}',14,4,'','admin/settings/ip-blocking/%','IP address blocking','t','',4,'','Manage blocked IP addresses.','',0),('admin/content/taxonomy/%','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:2:{i:0;s:23:\"taxonomy_overview_terms\";i:1;i:3;}',14,4,'','admin/content/taxonomy/%','List terms','t','',4,'','','',0),('admin/build/node-type/page','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:4:\"page\";s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:299:\"A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:4:\"page\";}}',15,4,'','admin/build/node-type/page','Page','t','',4,'','','',0),('admin/build/menu/settings','','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:1:{i:0;s:14:\"menu_configure\";}',15,4,'admin/build/menu','admin/build/menu','Settings','t','',128,'','','',5),('admin/settings/logging/dblog','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:20:\"dblog_admin_settings\";}',15,4,'','admin/settings/logging/dblog','Database logging','t','',6,'','Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.','',0),('admin/settings/filters/%','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:1:{i:0;i:3;}',14,4,'','admin/settings/filters/%','','filter_admin_format_title','a:1:{i:0;i:3;}',4,'','','',0),('admin/build/menu-customize/%','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:18:\"menu_overview_form\";i:1;i:3;}',14,4,'','admin/build/menu-customize/%','Customize menu','menu_overview_title','a:1:{i:0;i:3;}',4,'','','',0),('admin/settings/filters/%/edit','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_format_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Edit','t','',136,'','','',0),('admin/build/node-type/article/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"article\";s:4:\"name\";s:7:\"Article\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:401:\"An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"article\";}}',31,5,'admin/build/node-type/article','admin/build/node-type/article','Edit','t','',136,'','','',0),('admin/build/node-type/page/edit','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:14:\"node_type_form\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:4:\"page\";s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:299:\"A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:4:\"page\";}}',31,5,'admin/build/node-type/page','admin/build/node-type/page','Edit','t','',136,'','','',0),('admin/build/themes/settings/global','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:21:\"system_theme_settings\";}',31,5,'admin/build/themes/settings','admin/build/themes','Global settings','t','',136,'','','',-1),('admin/content/taxonomy/%/list','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:2:{i:0;s:23:\"taxonomy_overview_terms\";i:1;i:3;}',29,5,'admin/content/taxonomy/%','admin/content/taxonomy/%','List','t','',136,'','','',-10),('admin/build/menu-customize/%/list','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:18:\"menu_overview_form\";i:1;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','List items','t','',136,'','','',-10),('admin/build/modules/list/confirm','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:14:\"system_modules\";}',31,5,'','admin/build/modules/list/confirm','List','t','',4,'','','',0),('admin/build/modules/uninstall/confirm','','','user_access','a:1:{i:0;s:29:\"administer site configuration\";}','drupal_get_form','a:1:{i:0;s:24:\"system_modules_uninstall\";}',31,5,'','admin/build/modules/uninstall/confirm','Uninstall','t','',4,'','','',0),('admin/build/node-type/article/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:7:\"article\";s:4:\"name\";s:7:\"Article\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:401:\"An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:7:\"article\";}}',31,5,'','admin/build/node-type/article/delete','Delete','t','',4,'','','',0),('admin/build/node-type/page/delete','','','user_access','a:1:{i:0;s:24:\"administer content types\";}','drupal_get_form','a:2:{i:0;s:24:\"node_type_delete_confirm\";i:1;O:8:\"stdClass\":14:{s:4:\"type\";s:4:\"page\";s:4:\"name\";s:4:\"Page\";s:6:\"module\";s:4:\"node\";s:11:\"description\";s:299:\"A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.\";s:4:\"help\";s:0:\"\";s:9:\"has_title\";s:1:\"1\";s:11:\"title_label\";s:5:\"Title\";s:8:\"has_body\";s:1:\"1\";s:10:\"body_label\";s:4:\"Body\";s:14:\"min_word_count\";s:1:\"0\";s:6:\"custom\";s:1:\"1\";s:8:\"modified\";s:1:\"1\";s:6:\"locked\";s:1:\"0\";s:9:\"orig_type\";s:4:\"page\";}}',31,5,'','admin/build/node-type/page/delete','Delete','t','',4,'','','',0),('admin/content/taxonomy/edit/term','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_admin_term_edit','a:0:{}',31,5,'','admin/content/taxonomy/edit/term','Edit term','t','',4,'','','',0),('admin/build/block/list/js','','','user_access','a:1:{i:0;s:17:\"administer blocks\";}','block_admin_display_js','a:0:{}',31,5,'','admin/build/block/list/js','JavaScript List Form','t','',4,'','','',0),('admin/build/menu-customize/%/add','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:4:{i:0;s:14:\"menu_edit_item\";i:1;s:3:\"add\";i:2;N;i:3;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','Add item','t','',128,'','','',0),('admin/build/block/list/bluemarine','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/bluemarine/bluemarine.info\";s:4:\"name\";s:10:\"bluemarine\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:51:\"Tableless theme with a marine and ash color scheme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:10:\"bluemarine\";}',31,5,'admin/build/block/list','admin/build/block','Bluemarine','t','',128,'','','',0),('admin/build/themes/settings/bluemarine','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/bluemarine/bluemarine.info\";s:4:\"name\";s:10:\"bluemarine\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:51:\"Tableless theme with a marine and ash color scheme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:10:\"bluemarine\";}',31,5,'admin/build/themes/settings','admin/build/themes','Bluemarine','t','',128,'','','',0),('admin/build/block/list/chameleon','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":11:{s:8:\"filename\";s:31:\"themes/chameleon/chameleon.info\";s:4:\"name\";s:9:\"chameleon\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:32:\"themes/chameleon/chameleon.theme\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:10:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}}}','block_admin_display','a:1:{i:0;s:9:\"chameleon\";}',31,5,'admin/build/block/list','admin/build/block','Chameleon','t','',128,'','','',0),('admin/build/themes/settings/chameleon','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":11:{s:8:\"filename\";s:31:\"themes/chameleon/chameleon.info\";s:4:\"name\";s:9:\"chameleon\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:32:\"themes/chameleon/chameleon.theme\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:10:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:9:\"chameleon\";}',31,5,'admin/build/themes/settings','admin/build/themes','Chameleon','t','',128,'','','',0),('admin/settings/filters/%/configure','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_configure_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Configure','t','',128,'','','',1),('admin/settings/ip-blocking/delete/%','a:1:{i:4;s:15:\"blocked_ip_load\";}','','user_access','a:1:{i:0;s:18:\"block IP addresses\";}','drupal_get_form','a:2:{i:0;s:25:\"system_ip_blocking_delete\";i:1;i:4;}',30,5,'','admin/settings/ip-blocking/delete/%','Delete IP address','t','',4,'','','',0),('admin/build/menu-customize/%/delete','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_delete_menu_page','a:1:{i:0;i:3;}',29,5,'','admin/build/menu-customize/%/delete','Delete menu','t','',4,'','','',0),('admin/build/menu-customize/%/edit','a:1:{i:3;s:9:\"menu_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:3:{i:0;s:14:\"menu_edit_menu\";i:1;s:4:\"edit\";i:2;i:3;}',29,5,'admin/build/menu-customize/%','admin/build/menu-customize/%','Edit menu','t','',128,'','','',0),('admin/build/block/list/garland','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:27:\"themes/garland/garland.info\";s:4:\"name\";s:7:\"garland\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"1\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:7:\"garland\";}',31,5,'admin/build/block/list','admin/build/block','Garland','t','',136,'','','',-10),('admin/build/themes/settings/garland','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:27:\"themes/garland/garland.info\";s:4:\"name\";s:7:\"garland\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"1\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:7:\"garland\";}',31,5,'admin/build/themes/settings','admin/build/themes','Garland','t','',128,'','','',0),('admin/build/block/list/marvin','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:35:\"themes/chameleon/marvin/marvin.info\";s:4:\"name\";s:6:\"marvin\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:0:\"\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:9:\"chameleon\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:10:\"base_theme\";s:9:\"chameleon\";}}','block_admin_display','a:1:{i:0;s:6:\"marvin\";}',31,5,'admin/build/block/list','admin/build/block','Marvin','t','',128,'','','',0),('admin/build/themes/settings/marvin','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:35:\"themes/chameleon/marvin/marvin.info\";s:4:\"name\";s:6:\"marvin\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:0:\"\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:9:\"chameleon\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:10:\"base_theme\";s:9:\"chameleon\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:6:\"marvin\";}',31,5,'admin/build/themes/settings','admin/build/themes','Marvin','t','',128,'','','',0),('admin/build/block/list/minnelli','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:37:\"themes/garland/minnelli/minnelli.info\";s:4:\"name\";s:8:\"minnelli\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:12:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:7:\"garland\";}}','block_admin_display','a:1:{i:0;s:8:\"minnelli\";}',31,5,'admin/build/block/list','admin/build/block','Minnelli','t','',128,'','','',0),('admin/build/themes/settings/minnelli','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":13:{s:8:\"filename\";s:37:\"themes/garland/minnelli/minnelli.info\";s:4:\"name\";s:8:\"minnelli\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:12:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";s:6:\"engine\";s:11:\"phptemplate\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:6:\"engine\";s:11:\"phptemplate\";s:10:\"base_theme\";s:7:\"garland\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:8:\"minnelli\";}',31,5,'admin/build/themes/settings','admin/build/themes','Minnelli','t','',128,'','','',0),('admin/build/block/list/pushbutton','','','_block_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/pushbutton/pushbutton.info\";s:4:\"name\";s:10:\"pushbutton\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','block_admin_display','a:1:{i:0;s:10:\"pushbutton\";}',31,5,'admin/build/block/list','admin/build/block','Pushbutton','t','',128,'','','',0),('admin/build/themes/settings/pushbutton','','','_system_themes_access','a:1:{i:0;O:8:\"stdClass\":12:{s:8:\"filename\";s:33:\"themes/pushbutton/pushbutton.info\";s:4:\"name\";s:10:\"pushbutton\";s:4:\"type\";s:5:\"theme\";s:5:\"owner\";s:45:\"themes/engines/phptemplate/phptemplate.engine\";s:6:\"status\";s:1:\"0\";s:8:\"throttle\";s:1:\"0\";s:9:\"bootstrap\";s:1:\"0\";s:14:\"schema_version\";s:2:\"-1\";s:6:\"weight\";s:1:\"0\";s:4:\"info\";a:11:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:6:\"engine\";s:11:\"phptemplate\";}}','drupal_get_form','a:2:{i:0;s:21:\"system_theme_settings\";i:1;s:10:\"pushbutton\";}',31,5,'admin/build/themes/settings','admin/build/themes','Pushbutton','t','',128,'','','',0),('admin/settings/filters/%/order','a:1:{i:3;s:18:\"filter_format_load\";}','','user_access','a:1:{i:0;s:18:\"administer filters\";}','filter_admin_order_page','a:1:{i:0;i:3;}',29,5,'admin/settings/filters/%','admin/settings/filters/%','Rearrange','t','',128,'','','',2),('user/reset/%/%/%','a:3:{i:2;N;i:3;N;i:4;N;}','','1','a:0:{}','drupal_get_form','a:4:{i:0;s:15:\"user_pass_reset\";i:1;i:2;i:2;i:3;i:3;i:4;}',24,5,'','user/reset/%/%/%','Reset password','t','',4,'','','',0),('admin/content/taxonomy/add/vocabulary','','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','drupal_get_form','a:1:{i:0;s:24:\"taxonomy_form_vocabulary\";}',31,5,'admin/content/taxonomy','admin/content/taxonomy','Add vocabulary','t','',128,'','','',0),('admin/settings/actions/delete/%','a:1:{i:4;s:12:\"actions_load\";}','','user_access','a:1:{i:0;s:18:\"administer actions\";}','drupal_get_form','a:2:{i:0;s:26:\"system_actions_delete_form\";i:1;i:4;}',30,5,'','admin/settings/actions/delete/%','Delete action','t','',4,'','Delete an action.','',0),('node/%/revisions/%/delete','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:2:{i:0;i:1;i:1;s:6:\"delete\";}','drupal_get_form','a:2:{i:0;s:28:\"node_revision_delete_confirm\";i:1;i:1;}',21,5,'','node/%/revisions/%/delete','Delete earlier revision','t','',4,'','','',0),('node/%/revisions/%/revert','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:2:{i:0;i:1;i:1;s:6:\"update\";}','drupal_get_form','a:2:{i:0;s:28:\"node_revision_revert_confirm\";i:1;i:1;}',21,5,'','node/%/revisions/%/revert','Revert to earlier revision','t','',4,'','','',0),('node/%/revisions/%/view','a:2:{i:1;a:1:{s:9:\"node_load\";a:1:{i:0;i:3;}}i:3;N;}','','_node_revision_access','a:1:{i:0;i:1;}','node_show','a:3:{i:0;i:1;i:1;N;i:2;b:1;}',21,5,'','node/%/revisions/%/view','Revisions','t','',4,'','','',0),('admin/build/menu/item/%/delete','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','menu_item_delete_page','a:1:{i:0;i:4;}',61,6,'','admin/build/menu/item/%/delete','Delete menu item','t','',4,'','','',0),('admin/build/menu/item/%/edit','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:4:{i:0;s:14:\"menu_edit_item\";i:1;s:4:\"edit\";i:2;i:4;i:3;N;}',61,6,'','admin/build/menu/item/%/edit','Edit menu item','t','',4,'','','',0),('admin/content/taxonomy/edit/vocabulary/%','a:1:{i:5;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_admin_vocabulary_edit','a:1:{i:0;i:5;}',62,6,'','admin/content/taxonomy/edit/vocabulary/%','Edit vocabulary','t','',4,'','','',0),('admin/build/menu/item/%/reset','a:1:{i:4;s:14:\"menu_link_load\";}','','user_access','a:1:{i:0;s:15:\"administer menu\";}','drupal_get_form','a:2:{i:0;s:23:\"menu_reset_item_confirm\";i:1;i:4;}',61,6,'','admin/build/menu/item/%/reset','Reset menu item','t','',4,'','','',0),('admin/content/taxonomy/%/add/term','a:1:{i:3;s:24:\"taxonomy_vocabulary_load\";}','','user_access','a:1:{i:0;s:19:\"administer taxonomy\";}','taxonomy_add_term_page','a:1:{i:0;i:3;}',59,6,'admin/content/taxonomy/%','admin/content/taxonomy/%','Add term','t','',128,'','','',0);
/*!40000 ALTER TABLE `menu_router` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node`
--

DROP TABLE IF EXISTS `node`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node` (
  `nid` int(10) unsigned NOT NULL auto_increment,
  `vid` int(10) unsigned NOT NULL default '0',
  `type` varchar(32) NOT NULL default '',
  `language` varchar(12) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `uid` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '1',
  `created` int(11) NOT NULL default '0',
  `changed` int(11) NOT NULL default '0',
  `comment` int(11) NOT NULL default '0',
  `promote` int(11) NOT NULL default '0',
  `moderate` int(11) NOT NULL default '0',
  `sticky` int(11) NOT NULL default '0',
  `tnid` int(10) unsigned NOT NULL default '0',
  `translate` int(11) NOT NULL default '0',
  PRIMARY KEY  (`nid`),
  UNIQUE KEY `vid` (`vid`),
  KEY `node_changed` (`changed`),
  KEY `node_created` (`created`),
  KEY `node_moderate` (`moderate`),
  KEY `node_promote_status` (`promote`,`status`),
  KEY `node_status_type` (`status`,`type`,`nid`),
  KEY `node_title_type` (`title`,`type`(4)),
  KEY `node_type` (`type`(4)),
  KEY `uid` (`uid`),
  KEY `tnid` (`tnid`),
  KEY `translate` (`translate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node`
--

LOCK TABLES `node` WRITE;
/*!40000 ALTER TABLE `node` DISABLE KEYS */;
/*!40000 ALTER TABLE `node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_access`
--

DROP TABLE IF EXISTS `node_access`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node_access` (
  `nid` int(10) unsigned NOT NULL default '0',
  `gid` int(10) unsigned NOT NULL default '0',
  `realm` varchar(255) NOT NULL default '',
  `grant_view` tinyint(3) unsigned NOT NULL default '0',
  `grant_update` tinyint(3) unsigned NOT NULL default '0',
  `grant_delete` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`nid`,`gid`,`realm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node_access`
--

LOCK TABLES `node_access` WRITE;
/*!40000 ALTER TABLE `node_access` DISABLE KEYS */;
INSERT INTO `node_access` (`nid`, `gid`, `realm`, `grant_view`, `grant_update`, `grant_delete`) VALUES (0,0,'all',1,0,0);
/*!40000 ALTER TABLE `node_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_comment_statistics`
--

DROP TABLE IF EXISTS `node_comment_statistics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node_comment_statistics` (
  `nid` int(10) unsigned NOT NULL default '0',
  `last_comment_timestamp` int(11) NOT NULL default '0',
  `last_comment_name` varchar(60) default NULL,
  `last_comment_uid` int(11) NOT NULL default '0',
  `comment_count` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`nid`),
  KEY `node_comment_timestamp` (`last_comment_timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node_comment_statistics`
--

LOCK TABLES `node_comment_statistics` WRITE;
/*!40000 ALTER TABLE `node_comment_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `node_comment_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_counter`
--

DROP TABLE IF EXISTS `node_counter`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node_counter` (
  `nid` int(11) NOT NULL default '0',
  `totalcount` bigint(20) unsigned NOT NULL default '0',
  `daycount` mediumint(8) unsigned NOT NULL default '0',
  `timestamp` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node_counter`
--

LOCK TABLES `node_counter` WRITE;
/*!40000 ALTER TABLE `node_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `node_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_revisions`
--

DROP TABLE IF EXISTS `node_revisions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node_revisions` (
  `nid` int(10) unsigned NOT NULL default '0',
  `vid` int(10) unsigned NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `body` longtext NOT NULL,
  `teaser` longtext NOT NULL,
  `log` longtext NOT NULL,
  `timestamp` int(11) NOT NULL default '0',
  `format` int(11) NOT NULL default '0',
  PRIMARY KEY  (`vid`),
  KEY `nid` (`nid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node_revisions`
--

LOCK TABLES `node_revisions` WRITE;
/*!40000 ALTER TABLE `node_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `node_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_type`
--

DROP TABLE IF EXISTS `node_type`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `node_type` (
  `type` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `module` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `help` mediumtext NOT NULL,
  `has_title` tinyint(3) unsigned NOT NULL,
  `title_label` varchar(255) NOT NULL default '',
  `has_body` tinyint(3) unsigned NOT NULL,
  `body_label` varchar(255) NOT NULL default '',
  `min_word_count` smallint(5) unsigned NOT NULL,
  `custom` tinyint(4) NOT NULL default '0',
  `modified` tinyint(4) NOT NULL default '0',
  `locked` tinyint(4) NOT NULL default '0',
  `orig_type` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `node_type`
--

LOCK TABLES `node_type` WRITE;
/*!40000 ALTER TABLE `node_type` DISABLE KEYS */;
INSERT INTO `node_type` (`type`, `name`, `module`, `description`, `help`, `has_title`, `title_label`, `has_body`, `body_label`, `min_word_count`, `custom`, `modified`, `locked`, `orig_type`) VALUES ('page','Page','node','A <em>page</em>, similar in form to an <em>article</em>, is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site\'s initial home page.','',1,'Title',1,'Body',0,1,1,0,'page'),('article','Article','node','An <em>article</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with an <em>article</em> entry. By default, an <em>article</em> entry is automatically featured on the site\'s initial home page, and provides the ability to post comments.','',1,'Title',1,'Body',0,1,1,0,'article');
/*!40000 ALTER TABLE `node_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registry`
--

DROP TABLE IF EXISTS `registry`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `registry` (
  `name` varchar(255) NOT NULL default '',
  `type` varchar(9) NOT NULL default '',
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY  (`name`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `registry`
--

LOCK TABLES `registry` WRITE;
/*!40000 ALTER TABLE `registry` DISABLE KEYS */;
INSERT INTO `registry` (`name`, `type`, `filename`) VALUES ('block_help','function','./modules/block/block.module'),('block_theme','function','./modules/block/block.module'),('block_perm','function','./modules/block/block.module'),('block_menu','function','./modules/block/block.module'),('_block_themes_access','function','./modules/block/block.module'),('block_block','function','./modules/block/block.module'),('_block_rehash','function','./modules/block/block.module'),('block_box_get','function','./modules/block/block.module'),('block_box_form','function','./modules/block/block.module'),('block_box_save','function','./modules/block/block.module'),('block_user','function','./modules/block/block.module'),('block_list','function','./modules/block/block.module'),('_block_load_blocks','function','./modules/block/block.module'),('_block_render_blocks','function','./modules/block/block.module'),('_block_get_cache_id','function','./modules/block/block.module'),('block_admin_display','function','./modules/block/block.admin.inc'),('block_admin_display_form','function','./modules/block/block.admin.inc'),('block_admin_display_form_submit','function','./modules/block/block.admin.inc'),('_block_compare','function','./modules/block/block.admin.inc'),('block_admin_configure','function','./modules/block/block.admin.inc'),('block_admin_configure_validate','function','./modules/block/block.admin.inc'),('block_admin_configure_submit','function','./modules/block/block.admin.inc'),('block_add_block_form','function','./modules/block/block.admin.inc'),('block_add_block_form_validate','function','./modules/block/block.admin.inc'),('block_add_block_form_submit','function','./modules/block/block.admin.inc'),('block_box_delete','function','./modules/block/block.admin.inc'),('block_box_delete_submit','function','./modules/block/block.admin.inc'),('template_preprocess_block_admin_display_form','function','./modules/block/block.admin.inc'),('system_help','function','./modules/system/system.module'),('system_theme','function','./modules/system/system.module'),('system_perm','function','./modules/system/system.module'),('system_elements','function','./modules/system/system.module'),('system_menu','function','./modules/system/system.module'),('blocked_ip_load','function','./modules/system/system.module'),('_system_themes_access','function','./modules/system/system.module'),('system_init','function','./modules/system/system.module'),('system_user','function','./modules/system/system.module'),('system_block','function','./modules/system/system.module'),('system_admin_menu_block','function','./modules/system/system.module'),('system_admin_theme_submit','function','./modules/system/system.module'),('system_theme_select_form','function','./modules/system/system.module'),('system_check_directory','function','./modules/system/system.module'),('system_get_files_database','function','./modules/system/system.module'),('system_theme_default','function','./modules/system/system.module'),('system_theme_data','function','./modules/system/system.module'),('_system_theme_data','function','./modules/system/system.module'),('system_find_base_theme','function','./modules/system/system.module'),('system_region_list','function','./modules/system/system.module'),('system_default_region','function','./modules/system/system.module'),('system_initialize_theme_blocks','function','./modules/system/system.module'),('system_settings_form','function','./modules/system/system.module'),('system_settings_form_submit','function','./modules/system/system.module'),('_system_sort_requirements','function','./modules/system/system.module'),('system_node_type','function','./modules/system/system.module'),('confirm_form','function','./modules/system/system.module'),('system_admin_compact_mode','function','./modules/system/system.module'),('system_admin_compact_page','function','./modules/system/system.module'),('system_get_module_admin_tasks','function','./modules/system/system.module'),('system_cron','function','./modules/system/system.module'),('system_hook_info','function','./modules/system/system.module'),('system_action_info','function','./modules/system/system.module'),('system_actions_manage','function','./modules/system/system.module'),('system_actions_manage_form','function','./modules/system/system.module'),('system_actions_manage_form_submit','function','./modules/system/system.module'),('system_actions_configure','function','./modules/system/system.module'),('system_actions_configure_validate','function','./modules/system/system.module'),('system_actions_configure_submit','function','./modules/system/system.module'),('system_actions_delete_form','function','./modules/system/system.module'),('system_actions_delete_form_submit','function','./modules/system/system.module'),('system_action_delete_orphans_post','function','./modules/system/system.module'),('system_actions_remove_orphans','function','./modules/system/system.module'),('system_send_email_action_form','function','./modules/system/system.module'),('system_send_email_action_validate','function','./modules/system/system.module'),('system_send_email_action_submit','function','./modules/system/system.module'),('system_send_email_action','function','./modules/system/system.module'),('system_mail','function','./modules/system/system.module'),('system_message_action_form','function','./modules/system/system.module'),('system_message_action_submit','function','./modules/system/system.module'),('system_message_action','function','./modules/system/system.module'),('system_goto_action_form','function','./modules/system/system.module'),('system_goto_action_submit','function','./modules/system/system.module'),('system_goto_action','function','./modules/system/system.module'),('system_block_ip_action','function','./modules/system/system.module'),('_system_zonelist','function','./modules/system/system.module'),('system_check_http_request','function','./modules/system/system.module'),('theme_system_powered_by','function','./modules/system/system.module'),('theme_system_compact_link','function','./modules/system/system.module'),('system_main_admin_page','function','./modules/system/system.admin.inc'),('system_admin_menu_block_page','function','./modules/system/system.admin.inc'),('system_admin_by_module','function','./modules/system/system.admin.inc'),('system_settings_overview','function','./modules/system/system.admin.inc'),('system_admin_theme_settings','function','./modules/system/system.admin.inc'),('system_themes_form','function','./modules/system/system.admin.inc'),('system_themes_form_submit','function','./modules/system/system.admin.inc'),('system_theme_settings','function','./modules/system/system.admin.inc'),('system_theme_settings_submit','function','./modules/system/system.admin.inc'),('_system_is_incompatible','function','./modules/system/system.admin.inc'),('system_modules','function','./modules/system/system.admin.inc'),('system_sort_modules_by_info_name','function','./modules/system/system.admin.inc'),('system_modules_disable','function','./modules/system/system.admin.inc'),('system_modules_confirm_form','function','./modules/system/system.admin.inc'),('system_modules_submit','function','./modules/system/system.admin.inc'),('system_module_build_dependencies','function','./modules/system/system.admin.inc'),('system_modules_uninstall','function','./modules/system/system.admin.inc'),('system_modules_uninstall_confirm_form','function','./modules/system/system.admin.inc'),('system_modules_uninstall_validate','function','./modules/system/system.admin.inc'),('system_modules_uninstall_submit','function','./modules/system/system.admin.inc'),('system_ip_blocking','function','./modules/system/system.admin.inc'),('system_ip_blocking_form','function','./modules/system/system.admin.inc'),('system_ip_blocking_form_validate','function','./modules/system/system.admin.inc'),('system_ip_blocking_form_submit','function','./modules/system/system.admin.inc'),('system_ip_blocking_delete','function','./modules/system/system.admin.inc'),('system_ip_blocking_delete_submit','function','./modules/system/system.admin.inc'),('system_site_information_settings','function','./modules/system/system.admin.inc'),('system_site_information_settings_validate','function','./modules/system/system.admin.inc'),('system_error_reporting_settings','function','./modules/system/system.admin.inc'),('system_logging_overview','function','./modules/system/system.admin.inc'),('system_performance_settings','function','./modules/system/system.admin.inc'),('system_clear_cache_submit','function','./modules/system/system.admin.inc'),('system_file_system_settings','function','./modules/system/system.admin.inc'),('system_image_toolkit_settings','function','./modules/system/system.admin.inc'),('system_rss_feeds_settings','function','./modules/system/system.admin.inc'),('system_date_time_settings','function','./modules/system/system.admin.inc'),('system_date_time_settings_submit','function','./modules/system/system.admin.inc'),('system_date_time_lookup','function','./modules/system/system.admin.inc'),('system_site_maintenance_settings','function','./modules/system/system.admin.inc'),('system_clean_url_settings','function','./modules/system/system.admin.inc'),('system_status','function','./modules/system/system.admin.inc'),('system_run_cron','function','./modules/system/system.admin.inc'),('system_php','function','./modules/system/system.admin.inc'),('_system_sql','function','./modules/system/system.admin.inc'),('system_sql','function','./modules/system/system.admin.inc'),('system_batch_page','function','./modules/system/system.admin.inc'),('theme_admin_block','function','./modules/system/system.admin.inc'),('theme_admin_block_content','function','./modules/system/system.admin.inc'),('theme_admin_page','function','./modules/system/system.admin.inc'),('theme_system_admin_by_module','function','./modules/system/system.admin.inc'),('theme_status_report','function','./modules/system/system.admin.inc'),('theme_system_modules','function','./modules/system/system.admin.inc'),('theme_system_modules_uninstall','function','./modules/system/system.admin.inc'),('theme_system_theme_select_form','function','./modules/system/system.admin.inc'),('theme_system_themes_form','function','./modules/system/system.admin.inc'),('actions_do','function','./includes/actions.inc'),('actions_list','function','./includes/actions.inc'),('actions_get_all_actions','function','./includes/actions.inc'),('actions_actions_map','function','./includes/actions.inc'),('actions_function_lookup','function','./includes/actions.inc'),('actions_synchronize','function','./includes/actions.inc'),('actions_save','function','./includes/actions.inc'),('actions_load','function','./includes/actions.inc'),('actions_delete','function','./includes/actions.inc'),('_batch_page','function','./includes/batch.inc'),('_batch_start','function','./includes/batch.inc'),('_batch_progress_page_js','function','./includes/batch.inc'),('_batch_do','function','./includes/batch.inc'),('_batch_progress_page_nojs','function','./includes/batch.inc'),('_batch_process','function','./includes/batch.inc'),('_batch_current_set','function','./includes/batch.inc'),('_batch_next_set','function','./includes/batch.inc'),('_batch_finished','function','./includes/batch.inc'),('_batch_shutdown','function','./includes/batch.inc'),('timer_start','function','./includes/bootstrap.inc'),('timer_read','function','./includes/bootstrap.inc'),('timer_stop','function','./includes/bootstrap.inc'),('conf_path','function','./includes/bootstrap.inc'),('drupal_unset_globals','function','./includes/bootstrap.inc'),('conf_init','function','./includes/bootstrap.inc'),('drupal_get_filename','function','./includes/bootstrap.inc'),('variable_init','function','./includes/bootstrap.inc'),('variable_get','function','./includes/bootstrap.inc'),('variable_set','function','./includes/bootstrap.inc'),('variable_del','function','./includes/bootstrap.inc'),('page_get_cache','function','./includes/bootstrap.inc'),('bootstrap_invoke_all','function','./includes/bootstrap.inc'),('drupal_load','function','./includes/bootstrap.inc'),('drupal_page_header','function','./includes/bootstrap.inc'),('drupal_page_cache_header','function','./includes/bootstrap.inc'),('bootstrap_hooks','function','./includes/bootstrap.inc'),('drupal_unpack','function','./includes/bootstrap.inc'),('referer_uri','function','./includes/bootstrap.inc'),('check_plain','function','./includes/bootstrap.inc'),('drupal_validate_utf8','function','./includes/bootstrap.inc'),('request_uri','function','./includes/bootstrap.inc'),('watchdog','function','./includes/bootstrap.inc'),('drupal_set_message','function','./includes/bootstrap.inc'),('drupal_get_messages','function','./includes/bootstrap.inc'),('drupal_is_denied','function','./includes/bootstrap.inc'),('drupal_anonymous_user','function','./includes/bootstrap.inc'),('drupal_bootstrap','function','./includes/bootstrap.inc'),('_drupal_bootstrap','function','./includes/bootstrap.inc'),('drupal_maintenance_theme','function','./includes/bootstrap.inc'),('get_t','function','./includes/bootstrap.inc'),('drupal_init_language','function','./includes/bootstrap.inc'),('language_list','function','./includes/bootstrap.inc'),('language_default','function','./includes/bootstrap.inc'),('ip_address','function','./includes/bootstrap.inc'),('drupal_function_exists','function','./includes/bootstrap.inc'),('drupal_autoload_interface','function','./includes/bootstrap.inc'),('drupal_autoload_class','function','./includes/bootstrap.inc'),('_registry_check_code','function','./includes/bootstrap.inc'),('registry_mark_code','function','./includes/bootstrap.inc'),('drupal_rebuild_code_registry','function','./includes/bootstrap.inc'),('registry_cache_hook_implementations','function','./includes/bootstrap.inc'),('registry_cache_path_files','function','./includes/bootstrap.inc'),('registry_load_path_files','function','./includes/bootstrap.inc'),('registry_get_hook_implementations_cache','function','./includes/bootstrap.inc'),('cache_get','function','./includes/cache-install.inc'),('cache_set','function','./includes/cache-install.inc'),('cache_clear_all','function','./includes/cache-install.inc'),('drupal_set_content','function','./includes/common.inc'),('drupal_get_content','function','./includes/common.inc'),('drupal_set_breadcrumb','function','./includes/common.inc'),('drupal_get_breadcrumb','function','./includes/common.inc'),('drupal_set_html_head','function','./includes/common.inc'),('drupal_get_html_head','function','./includes/common.inc'),('drupal_clear_path_cache','function','./includes/common.inc'),('drupal_set_header','function','./includes/common.inc'),('drupal_get_headers','function','./includes/common.inc'),('drupal_add_feed','function','./includes/common.inc'),('drupal_get_feeds','function','./includes/common.inc'),('drupal_query_string_encode','function','./includes/common.inc'),('drupal_get_destination','function','./includes/common.inc'),('drupal_goto','function','./includes/common.inc'),('drupal_site_offline','function','./includes/common.inc'),('drupal_not_found','function','./includes/common.inc'),('drupal_access_denied','function','./includes/common.inc'),('drupal_http_request','function','./includes/common.inc'),('drupal_error_handler','function','./includes/common.inc'),('_fix_gpc_magic','function','./includes/common.inc'),('_fix_gpc_magic_files','function','./includes/common.inc'),('fix_gpc_magic','function','./includes/common.inc'),('t','function','./includes/common.inc'),('valid_email_address','function','./includes/common.inc'),('valid_url','function','./includes/common.inc'),('flood_register_event','function','./includes/common.inc'),('flood_is_allowed','function','./includes/common.inc'),('check_file','function','./includes/common.inc'),('check_url','function','./includes/common.inc'),('format_rss_channel','function','./includes/common.inc'),('format_rss_item','function','./includes/common.inc'),('format_xml_elements','function','./includes/common.inc'),('format_plural','function','./includes/common.inc'),('parse_size','function','./includes/common.inc'),('format_size','function','./includes/common.inc'),('format_interval','function','./includes/common.inc'),('format_date','function','./includes/common.inc'),('url','function','./includes/common.inc'),('drupal_attributes','function','./includes/common.inc'),('l','function','./includes/common.inc'),('drupal_page_footer','function','./includes/common.inc'),('drupal_map_assoc','function','./includes/common.inc'),('drupal_eval','function','./includes/common.inc'),('drupal_get_path','function','./includes/common.inc'),('base_path','function','./includes/common.inc'),('drupal_add_link','function','./includes/common.inc'),('drupal_add_css','function','./includes/common.inc'),('drupal_get_css','function','./includes/common.inc'),('drupal_build_css_cache','function','./includes/common.inc'),('_drupal_build_css_path','function','./includes/common.inc'),('drupal_load_stylesheet','function','./includes/common.inc'),('_drupal_load_stylesheet','function','./includes/common.inc'),('drupal_clear_css_cache','function','./includes/common.inc'),('drupal_add_js','function','./includes/common.inc'),('drupal_get_js','function','./includes/common.inc'),('drupal_add_tabledrag','function','./includes/common.inc'),('drupal_build_js_cache','function','./includes/common.inc'),('drupal_clear_js_cache','function','./includes/common.inc'),('drupal_to_js','function','./includes/common.inc'),('drupal_json','function','./includes/common.inc'),('drupal_urlencode','function','./includes/common.inc'),('drupal_random_bytes','function','./includes/common.inc'),('drupal_get_private_key','function','./includes/common.inc'),('drupal_get_token','function','./includes/common.inc'),('drupal_valid_token','function','./includes/common.inc'),('xmlrpc','function','./includes/common.inc'),('_drupal_bootstrap_full','function','./includes/common.inc'),('page_set_cache','function','./includes/common.inc'),('drupal_cron_run','function','./includes/common.inc'),('drupal_cron_cleanup','function','./includes/common.inc'),('drupal_system_listing','function','./includes/common.inc'),('drupal_alter','function','./includes/common.inc'),('drupal_render','function','./includes/common.inc'),('element_sort','function','./includes/common.inc'),('element_property','function','./includes/common.inc'),('element_properties','function','./includes/common.inc'),('element_child','function','./includes/common.inc'),('element_children','function','./includes/common.inc'),('drupal_common_theme','function','./includes/common.inc'),('drupal_get_schema','function','./includes/common.inc'),('drupal_install_schema','function','./includes/common.inc'),('drupal_uninstall_schema','function','./includes/common.inc'),('drupal_get_schema_unprocessed','function','./includes/common.inc'),('_drupal_initialize_schema','function','./includes/common.inc'),('drupal_schema_fields_sql','function','./includes/common.inc'),('drupal_write_record','function','./includes/common.inc'),('drupal_parse_info_file','function','./includes/common.inc'),('watchdog_severity_levels','function','./includes/common.inc'),('drupal_explode_tags','function','./includes/common.inc'),('drupal_implode_tags','function','./includes/common.inc'),('drupal_flush_all_caches','function','./includes/common.inc'),('_drupal_flush_css_js','function','./includes/common.inc'),('update_sql','function','./includes/database.inc'),('db_prefix_tables','function','./includes/database.inc'),('db_set_active','function','./includes/database.inc'),('_db_error_page','function','./includes/database.inc'),('db_is_active','function','./includes/database.inc'),('_db_query_callback','function','./includes/database.inc'),('db_placeholders','function','./includes/database.inc'),('_db_rewrite_sql','function','./includes/database.inc'),('db_rewrite_sql','function','./includes/database.inc'),('db_escape_table','function','./includes/database.inc'),('db_create_table','function','./includes/database.inc'),('db_field_names','function','./includes/database.inc'),('db_type_placeholder','function','./includes/database.inc'),('db_query','function','./includes/database.mysql-common.inc'),('db_create_table_sql','function','./includes/database.mysql-common.inc'),('_db_create_keys_sql','function','./includes/database.mysql-common.inc'),('_db_create_key_sql','function','./includes/database.mysql-common.inc'),('_db_process_field','function','./includes/database.mysql-common.inc'),('_db_create_field_sql','function','./includes/database.mysql-common.inc'),('db_type_map','function','./includes/database.mysql-common.inc'),('db_rename_table','function','./includes/database.mysql-common.inc'),('db_drop_table','function','./includes/database.mysql-common.inc'),('db_add_field','function','./includes/database.mysql-common.inc'),('db_drop_field','function','./includes/database.mysql-common.inc'),('db_field_set_default','function','./includes/database.mysql-common.inc'),('db_field_set_no_default','function','./includes/database.mysql-common.inc'),('db_add_primary_key','function','./includes/database.mysql-common.inc'),('db_drop_primary_key','function','./includes/database.mysql-common.inc'),('db_add_unique_key','function','./includes/database.mysql-common.inc'),('db_drop_unique_key','function','./includes/database.mysql-common.inc'),('db_add_index','function','./includes/database.mysql-common.inc'),('db_drop_index','function','./includes/database.mysql-common.inc'),('db_change_field','function','./includes/database.mysql-common.inc'),('db_last_insert_id','function','./includes/database.mysql-common.inc'),('db_status_report','function','./includes/database.mysql.inc'),('db_version','function','./includes/database.mysql.inc'),('db_connect','function','./includes/database.mysql.inc'),('_db_query','function','./includes/database.mysql.inc'),('db_fetch_object','function','./includes/database.mysql.inc'),('db_fetch_array','function','./includes/database.mysql.inc'),('db_result','function','./includes/database.mysql.inc'),('db_error','function','./includes/database.mysql.inc'),('db_affected_rows','function','./includes/database.mysql.inc'),('db_query_range','function','./includes/database.mysql.inc'),('db_query_temporary','function','./includes/database.mysql.inc'),('db_encode_blob','function','./includes/database.mysql.inc'),('db_decode_blob','function','./includes/database.mysql.inc'),('db_escape_string','function','./includes/database.mysql.inc'),('db_lock_table','function','./includes/database.mysql.inc'),('db_unlock_tables','function','./includes/database.mysql.inc'),('db_table_exists','function','./includes/database.mysql.inc'),('db_column_exists','function','./includes/database.mysql.inc'),('db_distinct_field','function','./includes/database.mysql.inc'),('db_check_setup','function','./includes/database.pgsql.inc'),('_db_create_index_sql','function','./includes/database.pgsql.inc'),('_db_create_keys','function','./includes/database.pgsql.inc'),('file_create_url','function','./includes/file.inc'),('file_create_path','function','./includes/file.inc'),('file_check_directory','function','./includes/file.inc'),('file_check_path','function','./includes/file.inc'),('file_check_location','function','./includes/file.inc'),('file_copy','function','./includes/file.inc'),('file_destination','function','./includes/file.inc'),('file_move','function','./includes/file.inc'),('file_munge_filename','function','./includes/file.inc'),('file_unmunge_filename','function','./includes/file.inc'),('file_create_filename','function','./includes/file.inc'),('file_delete','function','./includes/file.inc'),('file_space_used','function','./includes/file.inc'),('file_save_upload','function','./includes/file.inc'),('file_validate_name_length','function','./includes/file.inc'),('file_validate_extensions','function','./includes/file.inc'),('file_validate_size','function','./includes/file.inc'),('file_validate_is_image','function','./includes/file.inc'),('file_validate_image_resolution','function','./includes/file.inc'),('file_save_data','function','./includes/file.inc'),('file_set_status','function','./includes/file.inc'),('file_transfer','function','./includes/file.inc'),('file_download','function','./includes/file.inc'),('file_scan_directory','function','./includes/file.inc'),('file_directory_temp','function','./includes/file.inc'),('file_directory_path','function','./includes/file.inc'),('file_upload_max_size','function','./includes/file.inc'),('drupal_get_form','function','./includes/form.inc'),('drupal_rebuild_form','function','./includes/form.inc'),('form_get_cache','function','./includes/form.inc'),('form_set_cache','function','./includes/form.inc'),('drupal_execute','function','./includes/form.inc'),('drupal_retrieve_form','function','./includes/form.inc'),('drupal_process_form','function','./includes/form.inc'),('drupal_prepare_form','function','./includes/form.inc'),('drupal_validate_form','function','./includes/form.inc'),('drupal_render_form','function','./includes/form.inc'),('drupal_redirect_form','function','./includes/form.inc'),('_form_validate','function','./includes/form.inc'),('form_execute_handlers','function','./includes/form.inc'),('form_set_error','function','./includes/form.inc'),('form_get_errors','function','./includes/form.inc'),('form_get_error','function','./includes/form.inc'),('form_error','function','./includes/form.inc'),('form_builder','function','./includes/form.inc'),('_form_builder_handle_input_element','function','./includes/form.inc'),('_form_button_was_clicked','function','./includes/form.inc'),('_form_builder_ie_cleanup','function','./includes/form.inc'),('form_type_image_button_value','function','./includes/form.inc'),('form_type_checkbox_value','function','./includes/form.inc'),('form_type_checkboxes_value','function','./includes/form.inc'),('form_type_password_confirm_value','function','./includes/form.inc'),('form_type_select_value','function','./includes/form.inc'),('form_type_textfield_value','function','./includes/form.inc'),('form_type_token_value','function','./includes/form.inc'),('form_set_value','function','./includes/form.inc'),('_form_set_value','function','./includes/form.inc'),('_element_info','function','./includes/form.inc'),('form_options_flatten','function','./includes/form.inc'),('theme_select','function','./includes/form.inc'),('form_select_options','function','./includes/form.inc'),('form_get_options','function','./includes/form.inc'),('theme_fieldset','function','./includes/form.inc'),('theme_radio','function','./includes/form.inc'),('theme_radios','function','./includes/form.inc'),('theme_password_confirm','function','./includes/form.inc'),('expand_password_confirm','function','./includes/form.inc'),('password_confirm_validate','function','./includes/form.inc'),('theme_date','function','./includes/form.inc'),('expand_date','function','./includes/form.inc'),('date_validate','function','./includes/form.inc'),('map_month','function','./includes/form.inc'),('weight_value','function','./includes/form.inc'),('expand_radios','function','./includes/form.inc'),('form_expand_ahah','function','./includes/form.inc'),('theme_item','function','./includes/form.inc'),('theme_checkbox','function','./includes/form.inc'),('theme_checkboxes','function','./includes/form.inc'),('expand_checkboxes','function','./includes/form.inc'),('theme_submit','function','./includes/form.inc'),('theme_button','function','./includes/form.inc'),('theme_image_button','function','./includes/form.inc'),('theme_hidden','function','./includes/form.inc'),('theme_token','function','./includes/form.inc'),('theme_textfield','function','./includes/form.inc'),('theme_form','function','./includes/form.inc'),('theme_textarea','function','./includes/form.inc'),('theme_markup','function','./includes/form.inc'),('theme_password','function','./includes/form.inc'),('process_weight','function','./includes/form.inc'),('theme_file','function','./includes/form.inc'),('theme_form_element','function','./includes/form.inc'),('_form_set_class','function','./includes/form.inc'),('form_clean_id','function','./includes/form.inc'),('batch_set','function','./includes/form.inc'),('batch_process','function','./includes/form.inc'),('batch_get','function','./includes/form.inc'),('image_gd_info','function','./includes/image.gd.inc'),('image_gd_settings','function','./includes/image.gd.inc'),('image_gd_settings_validate','function','./includes/image.gd.inc'),('image_gd_check_settings','function','./includes/image.gd.inc'),('image_gd_resize','function','./includes/image.gd.inc'),('image_gd_rotate','function','./includes/image.gd.inc'),('image_gd_crop','function','./includes/image.gd.inc'),('image_gd_open','function','./includes/image.gd.inc'),('image_gd_close','function','./includes/image.gd.inc'),('image_get_available_toolkits','function','./includes/image.inc'),('image_get_toolkit','function','./includes/image.inc'),('image_toolkit_invoke','function','./includes/image.inc'),('image_get_info','function','./includes/image.inc'),('image_scale_and_crop','function','./includes/image.inc'),('image_scale','function','./includes/image.inc'),('image_resize','function','./includes/image.inc'),('image_rotate','function','./includes/image.inc'),('image_crop','function','./includes/image.inc'),('drupal_load_updates','function','./includes/install.inc'),('drupal_get_schema_versions','function','./includes/install.inc'),('drupal_get_installed_schema_version','function','./includes/install.inc'),('drupal_set_installed_schema_version','function','./includes/install.inc'),('drupal_install_profile_name','function','./includes/install.inc'),('drupal_detect_baseurl','function','./includes/install.inc'),('drupal_detect_database_types','function','./includes/install.inc'),('drupal_rewrite_settings','function','./includes/install.inc'),('drupal_get_install_files','function','./includes/install.inc'),('drupal_verify_profile','function','./includes/install.inc'),('drupal_install_modules','function','./includes/install.inc'),('_drupal_install_module','function','./includes/install.inc'),('drupal_install_system','function','./includes/install.inc'),('drupal_uninstall_module','function','./includes/install.inc'),('drupal_verify_install_file','function','./includes/install.inc'),('drupal_install_mkdir','function','./includes/install.inc'),('drupal_install_fix_file','function','./includes/install.inc'),('install_goto','function','./includes/install.inc'),('st','function','./includes/install.inc'),('drupal_check_profile','function','./includes/install.inc'),('drupal_requirements_severity','function','./includes/install.inc'),('drupal_check_module','function','./includes/install.inc'),('mysql_is_available','function','./includes/install.mysql.inc'),('drupal_test_mysql','function','./includes/install.mysql.inc'),('mysqli_is_available','function','./includes/install.mysqli.inc'),('drupal_test_mysqli','function','./includes/install.mysqli.inc'),('pgsql_is_available','function','./includes/install.pgsql.inc'),('drupal_test_pgsql','function','./includes/install.pgsql.inc'),('language_initialize','function','./includes/language.inc'),('language_from_browser','function','./includes/language.inc'),('language_url_rewrite','function','./includes/language.inc'),('locale_languages_overview_form','function','./includes/locale.inc'),('theme_locale_languages_overview_form','function','./includes/locale.inc'),('locale_languages_overview_form_submit','function','./includes/locale.inc'),('locale_languages_add_screen','function','./includes/locale.inc'),('locale_languages_predefined_form','function','./includes/locale.inc'),('locale_languages_custom_form','function','./includes/locale.inc'),('locale_languages_edit_form','function','./includes/locale.inc'),('_locale_languages_common_controls','function','./includes/locale.inc'),('locale_languages_predefined_form_validate','function','./includes/locale.inc'),('locale_languages_predefined_form_submit','function','./includes/locale.inc'),('locale_languages_edit_form_validate','function','./includes/locale.inc'),('locale_languages_edit_form_submit','function','./includes/locale.inc'),('locale_languages_delete_form','function','./includes/locale.inc'),('locale_languages_delete_form_submit','function','./includes/locale.inc'),('locale_languages_configure_form','function','./includes/locale.inc'),('locale_languages_configure_form_submit','function','./includes/locale.inc'),('locale_translate_overview_screen','function','./includes/locale.inc'),('locale_translate_seek_screen','function','./includes/locale.inc'),('locale_translate_seek_form','function','./includes/locale.inc'),('locale_translate_import_form','function','./includes/locale.inc'),('locale_translate_import_form_submit','function','./includes/locale.inc'),('locale_translate_export_screen','function','./includes/locale.inc'),('locale_translate_export_po_form','function','./includes/locale.inc'),('locale_translate_export_pot_form','function','./includes/locale.inc'),('locale_translate_export_po_form_submit','function','./includes/locale.inc'),('locale_translate_edit_form','function','./includes/locale.inc'),('locale_translate_edit_form_submit','function','./includes/locale.inc'),('locale_translate_delete','function','./includes/locale.inc'),('locale_add_language','function','./includes/locale.inc'),('_locale_import_po','function','./includes/locale.inc'),('_locale_import_read_po','function','./includes/locale.inc'),('_locale_import_message','function','./includes/locale.inc'),('_locale_import_one_string','function','./includes/locale.inc'),('_locale_import_one_string_db','function','./includes/locale.inc'),('_locale_import_parse_header','function','./includes/locale.inc'),('_locale_import_parse_plural_forms','function','./includes/locale.inc'),('_locale_import_parse_arithmetic','function','./includes/locale.inc'),('_locale_import_tokenize_formula','function','./includes/locale.inc'),('_locale_import_append_plural','function','./includes/locale.inc'),('_locale_import_shorten_comments','function','./includes/locale.inc'),('_locale_import_parse_quoted','function','./includes/locale.inc'),('_locale_parse_js_file','function','./includes/locale.inc'),('_locale_export_get_strings','function','./includes/locale.inc'),('_locale_export_po_generate','function','./includes/locale.inc'),('_locale_export_po','function','./includes/locale.inc'),('_locale_export_string','function','./includes/locale.inc'),('_locale_export_wrap','function','./includes/locale.inc'),('_locale_export_remove_plural','function','./includes/locale.inc'),('_locale_translate_seek','function','./includes/locale.inc'),('_locale_translate_seek_query','function','./includes/locale.inc'),('_locale_invalidate_js','function','./includes/locale.inc'),('_locale_rebuild_js','function','./includes/locale.inc'),('_locale_translate_language_list','function','./includes/locale.inc'),('_locale_prepare_predefined_list','function','./includes/locale.inc'),('_locale_get_predefined_list','function','./includes/locale.inc'),('locale_batch_by_language','function','./includes/locale.inc'),('locale_batch_by_component','function','./includes/locale.inc'),('_locale_batch_build','function','./includes/locale.inc'),('_locale_batch_import','function','./includes/locale.inc'),('_locale_batch_system_finished','function','./includes/locale.inc'),('_locale_batch_language_finished','function','./includes/locale.inc'),('drupal_mail','function','./includes/mail.inc'),('drupal_mail_send','function','./includes/mail.inc'),('drupal_wrap_mail','function','./includes/mail.inc'),('drupal_html_to_text','function','./includes/mail.inc'),('_drupal_wrap_mail_line','function','./includes/mail.inc'),('_drupal_html_to_mail_urls','function','./includes/mail.inc'),('_drupal_html_to_text_clean','function','./includes/mail.inc'),('_drupal_html_to_text_pad','function','./includes/mail.inc'),('menu_get_ancestors','function','./includes/menu.inc'),('menu_unserialize','function','./includes/menu.inc'),('menu_set_item','function','./includes/menu.inc'),('menu_get_item','function','./includes/menu.inc'),('menu_execute_active_handler','function','./includes/menu.inc'),('_menu_load_objects','function','./includes/menu.inc'),('_menu_check_access','function','./includes/menu.inc'),('_menu_item_localize','function','./includes/menu.inc'),('_menu_translate','function','./includes/menu.inc'),('_menu_link_map_translate','function','./includes/menu.inc'),('menu_tail_to_arg','function','./includes/menu.inc'),('_menu_link_translate','function','./includes/menu.inc'),('menu_get_object','function','./includes/menu.inc'),('menu_tree','function','./includes/menu.inc'),('menu_tree_output','function','./includes/menu.inc'),('menu_tree_all_data','function','./includes/menu.inc'),('menu_tree_page_data','function','./includes/menu.inc'),('_menu_tree_cid','function','./includes/menu.inc'),('menu_tree_collect_node_links','function','./includes/menu.inc'),('menu_tree_check_access','function','./includes/menu.inc'),('_menu_tree_check_access','function','./includes/menu.inc'),('menu_tree_data','function','./includes/menu.inc'),('_menu_tree_data','function','./includes/menu.inc'),('theme_menu_item_link','function','./includes/menu.inc'),('theme_menu_tree','function','./includes/menu.inc'),('theme_menu_item','function','./includes/menu.inc'),('theme_menu_local_task','function','./includes/menu.inc'),('drupal_help_arg','function','./includes/menu.inc'),('menu_get_active_help','function','./includes/menu.inc'),('menu_get_names','function','./includes/menu.inc'),('menu_list_system_menus','function','./includes/menu.inc'),('menu_primary_links','function','./includes/menu.inc'),('menu_secondary_links','function','./includes/menu.inc'),('menu_navigation_links','function','./includes/menu.inc'),('menu_local_tasks','function','./includes/menu.inc'),('menu_primary_local_tasks','function','./includes/menu.inc'),('menu_secondary_local_tasks','function','./includes/menu.inc'),('menu_tab_root_path','function','./includes/menu.inc'),('theme_menu_local_tasks','function','./includes/menu.inc'),('menu_set_active_menu_name','function','./includes/menu.inc'),('menu_get_active_menu_name','function','./includes/menu.inc'),('menu_set_active_item','function','./includes/menu.inc'),('menu_set_active_trail','function','./includes/menu.inc'),('menu_get_active_trail','function','./includes/menu.inc'),('menu_get_active_breadcrumb','function','./includes/menu.inc'),('menu_get_active_title','function','./includes/menu.inc'),('menu_link_load','function','./includes/menu.inc'),('menu_cache_clear','function','./includes/menu.inc'),('menu_cache_clear_all','function','./includes/menu.inc'),('menu_rebuild','function','./includes/menu.inc'),('menu_router_build','function','./includes/menu.inc'),('_menu_link_build','function','./includes/menu.inc'),('_menu_navigation_links_rebuild','function','./includes/menu.inc'),('menu_link_delete','function','./includes/menu.inc'),('_menu_delete_item','function','./includes/menu.inc'),('menu_link_save','function','./includes/menu.inc'),('_menu_clear_page_cache','function','./includes/menu.inc'),('_menu_set_expanded_menus','function','./includes/menu.inc'),('_menu_find_router_path','function','./includes/menu.inc'),('menu_link_maintain','function','./includes/menu.inc'),('menu_link_children_relative_depth','function','./includes/menu.inc'),('_menu_link_move_children','function','./includes/menu.inc'),('_menu_update_parental_status','function','./includes/menu.inc'),('_menu_link_parents_set','function','./includes/menu.inc'),('_menu_router_build','function','./includes/menu.inc'),('menu_path_is_external','function','./includes/menu.inc'),('_menu_site_is_offline','function','./includes/menu.inc'),('menu_valid_path','function','./includes/menu.inc'),('module_load_all','function','./includes/module.inc'),('module_iterate','function','./includes/module.inc'),('module_list','function','./includes/module.inc'),('module_rebuild_cache','function','./includes/module.inc'),('_module_build_dependencies','function','./includes/module.inc'),('module_exists','function','./includes/module.inc'),('module_load_install','function','./includes/module.inc'),('module_load_include','function','./includes/module.inc'),('module_load_all_includes','function','./includes/module.inc'),('module_enable','function','./includes/module.inc'),('module_disable','function','./includes/module.inc'),('module_hook','function','./includes/module.inc'),('module_implements','function','./includes/module.inc'),('module_invoke','function','./includes/module.inc'),('module_invoke_all','function','./includes/module.inc'),('drupal_required_modules','function','./includes/module.inc'),('pager_query','function','./includes/pager.inc'),('pager_get_querystring','function','./includes/pager.inc'),('theme_pager','function','./includes/pager.inc'),('theme_pager_first','function','./includes/pager.inc'),('theme_pager_previous','function','./includes/pager.inc'),('theme_pager_next','function','./includes/pager.inc'),('theme_pager_last','function','./includes/pager.inc'),('theme_pager_link','function','./includes/pager.inc'),('pager_load_array','function','./includes/pager.inc'),('_password_itoa64','function','./includes/password.inc'),('_password_base64_encode','function','./includes/password.inc'),('_password_generate_salt','function','./includes/password.inc'),('_password_crypt','function','./includes/password.inc'),('_password_get_count_log2','function','./includes/password.inc'),('user_hash_password','function','./includes/password.inc'),('user_check_password','function','./includes/password.inc'),('user_needs_new_hash','function','./includes/password.inc'),('drupal_init_path','function','./includes/path.inc'),('drupal_lookup_path','function','./includes/path.inc'),('drupal_get_path_alias','function','./includes/path.inc'),('drupal_get_normal_path','function','./includes/path.inc'),('arg','function','./includes/path.inc'),('drupal_get_title','function','./includes/path.inc'),('drupal_set_title','function','./includes/path.inc'),('drupal_is_front_page','function','./includes/path.inc'),('drupal_match_path','function','./includes/path.inc'),('_drupal_rebuild_code_registry','function','./includes/registry.inc'),('registry_get_parsed_files','function','./includes/registry.inc'),('_registry_parse_files','function','./includes/registry.inc'),('_registry_parse_file','function','./includes/registry.inc'),('_registry_get_resource_name','function','./includes/registry.inc'),('_registry_skip_body','function','./includes/registry.inc'),('sess_open','function','./includes/session.inc'),('sess_close','function','./includes/session.inc'),('sess_read','function','./includes/session.inc'),('sess_write','function','./includes/session.inc'),('sess_regenerate','function','./includes/session.inc'),('sess_count','function','./includes/session.inc'),('sess_destroy_sid','function','./includes/session.inc'),('sess_destroy_uid','function','./includes/session.inc'),('sess_gc','function','./includes/session.inc'),('session_save_session','function','./includes/session.inc'),('tablesort_init','function','./includes/tablesort.inc'),('tablesort_sql','function','./includes/tablesort.inc'),('tablesort_header','function','./includes/tablesort.inc'),('tablesort_cell','function','./includes/tablesort.inc'),('tablesort_get_querystring','function','./includes/tablesort.inc'),('tablesort_get_order','function','./includes/tablesort.inc'),('tablesort_get_sort','function','./includes/tablesort.inc'),('init_theme','function','./includes/theme.inc'),('_init_theme','function','./includes/theme.inc'),('theme_get_registry','function','./includes/theme.inc'),('_theme_set_registry','function','./includes/theme.inc'),('_theme_load_registry','function','./includes/theme.inc'),('_theme_save_registry','function','./includes/theme.inc'),('drupal_rebuild_theme_registry','function','./includes/theme.inc'),('_theme_process_registry','function','./includes/theme.inc'),('_theme_build_registry','function','./includes/theme.inc'),('list_themes','function','./includes/theme.inc'),('theme','function','./includes/theme.inc'),('drupal_discover_template','function','./includes/theme.inc'),('path_to_theme','function','./includes/theme.inc'),('drupal_find_theme_functions','function','./includes/theme.inc'),('drupal_find_theme_templates','function','./includes/theme.inc'),('theme_get_settings','function','./includes/theme.inc'),('theme_get_setting','function','./includes/theme.inc'),('theme_render_template','function','./includes/theme.inc'),('theme_placeholder','function','./includes/theme.inc'),('theme_status_messages','function','./includes/theme.inc'),('theme_links','function','./includes/theme.inc'),('theme_image','function','./includes/theme.inc'),('theme_breadcrumb','function','./includes/theme.inc'),('theme_help','function','./includes/theme.inc'),('theme_submenu','function','./includes/theme.inc'),('theme_table','function','./includes/theme.inc'),('theme_table_select_header_cell','function','./includes/theme.inc'),('theme_tablesort_indicator','function','./includes/theme.inc'),('theme_box','function','./includes/theme.inc'),('theme_mark','function','./includes/theme.inc'),('theme_item_list','function','./includes/theme.inc'),('theme_more_help_link','function','./includes/theme.inc'),('theme_xml_icon','function','./includes/theme.inc'),('theme_feed_icon','function','./includes/theme.inc'),('theme_more_link','function','./includes/theme.inc'),('theme_closure','function','./includes/theme.inc'),('theme_blocks','function','./includes/theme.inc'),('theme_username','function','./includes/theme.inc'),('theme_progress_bar','function','./includes/theme.inc'),('theme_indentation','function','./includes/theme.inc'),('_theme_table_cell','function','./includes/theme.inc'),('template_preprocess','function','./includes/theme.inc'),('template_preprocess_page','function','./includes/theme.inc'),('template_preprocess_node','function','./includes/theme.inc'),('template_preprocess_block','function','./includes/theme.inc'),('_drupal_maintenance_theme','function','./includes/theme.maintenance.inc'),('_theme_load_offline_registry','function','./includes/theme.maintenance.inc'),('theme_task_list','function','./includes/theme.maintenance.inc'),('theme_install_page','function','./includes/theme.maintenance.inc'),('theme_update_page','function','./includes/theme.maintenance.inc'),('template_preprocess_maintenance_page','function','./includes/theme.maintenance.inc'),('unicode_check','function','./includes/unicode.inc'),('_unicode_check','function','./includes/unicode.inc'),('unicode_requirements','function','./includes/unicode.inc'),('drupal_xml_parser_create','function','./includes/unicode.inc'),('drupal_convert_to_utf8','function','./includes/unicode.inc'),('drupal_truncate_bytes','function','./includes/unicode.inc'),('truncate_utf8','function','./includes/unicode.inc'),('mime_header_encode','function','./includes/unicode.inc'),('mime_header_decode','function','./includes/unicode.inc'),('_mime_header_decode','function','./includes/unicode.inc'),('decode_entities','function','./includes/unicode.inc'),('_decode_entities','function','./includes/unicode.inc'),('drupal_strlen','function','./includes/unicode.inc'),('drupal_strtoupper','function','./includes/unicode.inc'),('drupal_strtolower','function','./includes/unicode.inc'),('_unicode_caseflip','function','./includes/unicode.inc'),('drupal_ucfirst','function','./includes/unicode.inc'),('drupal_substr','function','./includes/unicode.inc'),('xmlrpc_value','function','./includes/xmlrpc.inc'),('xmlrpc_value_calculate_type','function','./includes/xmlrpc.inc'),('xmlrpc_value_get_xml','function','./includes/xmlrpc.inc'),('xmlrpc_message','function','./includes/xmlrpc.inc'),('xmlrpc_message_parse','function','./includes/xmlrpc.inc'),('xmlrpc_message_set','function','./includes/xmlrpc.inc'),('xmlrpc_message_get','function','./includes/xmlrpc.inc'),('xmlrpc_message_tag_open','function','./includes/xmlrpc.inc'),('xmlrpc_message_cdata','function','./includes/xmlrpc.inc'),('xmlrpc_message_tag_close','function','./includes/xmlrpc.inc'),('xmlrpc_request','function','./includes/xmlrpc.inc'),('xmlrpc_error','function','./includes/xmlrpc.inc'),('xmlrpc_error_get_xml','function','./includes/xmlrpc.inc'),('xmlrpc_date','function','./includes/xmlrpc.inc'),('xmlrpc_date_get_xml','function','./includes/xmlrpc.inc'),('xmlrpc_base64','function','./includes/xmlrpc.inc'),('xmlrpc_base64_get_xml','function','./includes/xmlrpc.inc'),('_xmlrpc','function','./includes/xmlrpc.inc'),('xmlrpc_errno','function','./includes/xmlrpc.inc'),('xmlrpc_error_msg','function','./includes/xmlrpc.inc'),('xmlrpc_server','function','./includes/xmlrpcs.inc'),('xmlrpc_server_error','function','./includes/xmlrpcs.inc'),('xmlrpc_server_output','function','./includes/xmlrpcs.inc'),('xmlrpc_server_set','function','./includes/xmlrpcs.inc'),('xmlrpc_server_get','function','./includes/xmlrpcs.inc'),('xmlrpc_server_call','function','./includes/xmlrpcs.inc'),('xmlrpc_server_multicall','function','./includes/xmlrpcs.inc'),('xmlrpc_server_list_methods','function','./includes/xmlrpcs.inc'),('xmlrpc_server_get_capabilities','function','./includes/xmlrpcs.inc'),('xmlrpc_server_method_signature','function','./includes/xmlrpcs.inc'),('xmlrpc_server_method_help','function','./includes/xmlrpcs.inc'),('filter_help','function','./modules/filter/filter.module'),('filter_theme','function','./modules/filter/filter.module'),('filter_menu','function','./modules/filter/filter.module'),('filter_format_load','function','./modules/filter/filter.module'),('filter_admin_format_title','function','./modules/filter/filter.module'),('filter_perm','function','./modules/filter/filter.module'),('filter_cron','function','./modules/filter/filter.module'),('filter_filter_tips','function','./modules/filter/filter.module'),('filter_formats','function','./modules/filter/filter.module'),('filter_list_all','function','./modules/filter/filter.module'),('_filter_list_cmp','function','./modules/filter/filter.module'),('filter_resolve_format','function','./modules/filter/filter.module'),('filter_format_allowcache','function','./modules/filter/filter.module'),('filter_list_format','function','./modules/filter/filter.module'),('check_markup','function','./modules/filter/filter.module'),('filter_form','function','./modules/filter/filter.module'),('filter_form_validate','function','./modules/filter/filter.module'),('filter_access','function','./modules/filter/filter.module'),('_filter_tips','function','./modules/filter/filter.module'),('theme_filter_tips_more_info','function','./modules/filter/filter.module'),('filter_filter','function','./modules/filter/filter.module'),('_filter_html_settings','function','./modules/filter/filter.module'),('_filter_html','function','./modules/filter/filter.module'),('_filter_url_settings','function','./modules/filter/filter.module'),('_filter_url','function','./modules/filter/filter.module'),('_filter_htmlcorrector','function','./modules/filter/filter.module'),('_filter_url_parse_full_links','function','./modules/filter/filter.module'),('_filter_url_parse_partial_links','function','./modules/filter/filter.module'),('_filter_url_trim','function','./modules/filter/filter.module'),('_filter_autop','function','./modules/filter/filter.module'),('filter_xss_admin','function','./modules/filter/filter.module'),('filter_xss','function','./modules/filter/filter.module'),('_filter_xss_split','function','./modules/filter/filter.module'),('_filter_xss_attributes','function','./modules/filter/filter.module'),('filter_xss_bad_protocol','function','./modules/filter/filter.module'),('filter_admin_overview','function','./modules/filter/filter.admin.inc'),('filter_admin_overview_submit','function','./modules/filter/filter.admin.inc'),('theme_filter_admin_overview','function','./modules/filter/filter.admin.inc'),('filter_admin_format_page','function','./modules/filter/filter.admin.inc'),('filter_admin_format_form','function','./modules/filter/filter.admin.inc'),('filter_admin_format_form_validate','function','./modules/filter/filter.admin.inc'),('filter_admin_format_form_submit','function','./modules/filter/filter.admin.inc'),('filter_admin_delete','function','./modules/filter/filter.admin.inc'),('filter_admin_delete_submit','function','./modules/filter/filter.admin.inc'),('filter_admin_configure_page','function','./modules/filter/filter.admin.inc'),('filter_admin_configure','function','./modules/filter/filter.admin.inc'),('filter_admin_configure_submit','function','./modules/filter/filter.admin.inc'),('filter_admin_order_page','function','./modules/filter/filter.admin.inc'),('filter_admin_order','function','./modules/filter/filter.admin.inc'),('theme_filter_admin_order','function','./modules/filter/filter.admin.inc'),('filter_admin_order_submit','function','./modules/filter/filter.admin.inc'),('filter_tips_long','function','./modules/filter/filter.pages.inc'),('theme_filter_tips','function','./modules/filter/filter.pages.inc'),('node_help','function','./modules/node/node.module'),('node_theme','function','./modules/node/node.module'),('node_cron','function','./modules/node/node.module'),('node_title_list','function','./modules/node/node.module'),('theme_node_list','function','./modules/node/node.module'),('node_tag_new','function','./modules/node/node.module'),('node_last_viewed','function','./modules/node/node.module'),('node_mark','function','./modules/node/node.module'),('node_teaser_js','function','./modules/node/node.module'),('node_teaser_include_verify','function','./modules/node/node.module'),('node_teaser','function','./modules/node/node.module'),('node_get_types','function','./modules/node/node.module'),('node_types_rebuild','function','./modules/node/node.module'),('node_type_save','function','./modules/node/node.module'),('node_type_delete','function','./modules/node/node.module'),('node_type_update_nodes','function','./modules/node/node.module'),('_node_types_build','function','./modules/node/node.module'),('_node_type_set_defaults','function','./modules/node/node.module'),('node_hook','function','./modules/node/node.module'),('node_invoke','function','./modules/node/node.module'),('node_invoke_nodeapi','function','./modules/node/node.module'),('node_load','function','./modules/node/node.module'),('node_validate','function','./modules/node/node.module'),('node_submit','function','./modules/node/node.module'),('node_save','function','./modules/node/node.module'),('_node_save_revision','function','./modules/node/node.module'),('node_delete','function','./modules/node/node.module'),('node_view','function','./modules/node/node.module'),('node_prepare','function','./modules/node/node.module'),('node_build_content','function','./modules/node/node.module'),('node_show','function','./modules/node/node.module'),('theme_node_log_message','function','./modules/node/node.module'),('node_perm','function','./modules/node/node.module'),('_node_rankings','function','./modules/node/node.module'),('node_search','function','./modules/node/node.module'),('node_ranking','function','./modules/node/node.module'),('node_user','function','./modules/node/node.module'),('theme_node_search_admin','function','./modules/node/node.module'),('node_comment_mode','function','./modules/node/node.module'),('node_link','function','./modules/node/node.module'),('_node_revision_access','function','./modules/node/node.module'),('_node_add_access','function','./modules/node/node.module'),('node_menu','function','./modules/node/node.module'),('node_page_title','function','./modules/node/node.module'),('node_init','function','./modules/node/node.module'),('node_last_changed','function','./modules/node/node.module'),('node_revision_list','function','./modules/node/node.module'),('node_block','function','./modules/node/node.module'),('node_feed','function','./modules/node/node.module'),('node_page_default','function','./modules/node/node.module'),('node_page_view','function','./modules/node/node.module'),('node_update_index','function','./modules/node/node.module'),('_node_index_node','function','./modules/node/node.module'),('node_form_alter','function','./modules/node/node.module'),('node_search_validate','function','./modules/node/node.module'),('node_access','function','./modules/node/node.module'),('_node_access_join_sql','function','./modules/node/node.module'),('_node_access_where_sql','function','./modules/node/node.module'),('node_access_grants','function','./modules/node/node.module'),('node_access_view_all_nodes','function','./modules/node/node.module'),('node_db_rewrite_sql','function','./modules/node/node.module'),('node_access_acquire_grants','function','./modules/node/node.module'),('node_access_write_grants','function','./modules/node/node.module'),('node_access_needs_rebuild','function','./modules/node/node.module'),('node_access_rebuild','function','./modules/node/node.module'),('_node_access_rebuild_batch_operation','function','./modules/node/node.module'),('_node_access_rebuild_batch_finished','function','./modules/node/node.module'),('node_content_access','function','./modules/node/node.module'),('node_content_form','function','./modules/node/node.module'),('node_forms','function','./modules/node/node.module'),('theme_node_submitted','function','./modules/node/node.module'),('node_hook_info','function','./modules/node/node.module'),('node_action_info','function','./modules/node/node.module'),('node_publish_action','function','./modules/node/node.module'),('node_unpublish_action','function','./modules/node/node.module'),('node_make_sticky_action','function','./modules/node/node.module'),('node_make_unsticky_action','function','./modules/node/node.module'),('node_promote_action','function','./modules/node/node.module'),('node_unpromote_action','function','./modules/node/node.module'),('node_save_action','function','./modules/node/node.module'),('node_assign_owner_action','function','./modules/node/node.module'),('node_assign_owner_action_form','function','./modules/node/node.module'),('node_assign_owner_action_validate','function','./modules/node/node.module'),('node_assign_owner_action_submit','function','./modules/node/node.module'),('node_unpublish_by_keyword_action_form','function','./modules/node/node.module'),('node_unpublish_by_keyword_action_submit','function','./modules/node/node.module'),('node_unpublish_by_keyword_action','function','./modules/node/node.module'),('node_list_permissions','function','./modules/node/node.module'),('node_overview_types','function','./modules/node/content_types.inc'),('node_type_form','function','./modules/node/content_types.inc'),('node_type_form_validate','function','./modules/node/content_types.inc'),('node_type_form_submit','function','./modules/node/content_types.inc'),('node_node_type','function','./modules/node/content_types.inc'),('node_type_reset','function','./modules/node/content_types.inc'),('node_type_delete_confirm','function','./modules/node/content_types.inc'),('node_type_delete_confirm_submit','function','./modules/node/content_types.inc'),('node_configure','function','./modules/node/node.admin.inc'),('node_configure_validate','function','./modules/node/node.admin.inc'),('node_configure_rebuild_confirm','function','./modules/node/node.admin.inc'),('node_configure_rebuild_confirm_submit','function','./modules/node/node.admin.inc'),('node_node_operations','function','./modules/node/node.admin.inc'),('node_filters','function','./modules/node/node.admin.inc'),('node_build_filter_query','function','./modules/node/node.admin.inc'),('node_filter_form','function','./modules/node/node.admin.inc'),('theme_node_filter_form','function','./modules/node/node.admin.inc'),('theme_node_filters','function','./modules/node/node.admin.inc'),('node_filter_form_submit','function','./modules/node/node.admin.inc'),('node_mass_update','function','./modules/node/node.admin.inc'),('_node_mass_update_helper','function','./modules/node/node.admin.inc'),('_node_mass_update_batch_process','function','./modules/node/node.admin.inc'),('_node_mass_update_batch_finished','function','./modules/node/node.admin.inc'),('node_admin_content','function','./modules/node/node.admin.inc'),('node_admin_nodes','function','./modules/node/node.admin.inc'),('node_admin_nodes_validate','function','./modules/node/node.admin.inc'),('node_admin_nodes_submit','function','./modules/node/node.admin.inc'),('theme_node_admin_nodes','function','./modules/node/node.admin.inc'),('node_multiple_delete_confirm','function','./modules/node/node.admin.inc'),('node_multiple_delete_confirm_submit','function','./modules/node/node.admin.inc'),('node_page_edit','function','./modules/node/node.pages.inc'),('node_add_page','function','./modules/node/node.pages.inc'),('theme_node_add_list','function','./modules/node/node.pages.inc'),('node_add','function','./modules/node/node.pages.inc'),('node_form_validate','function','./modules/node/node.pages.inc'),('node_object_prepare','function','./modules/node/node.pages.inc'),('node_form','function','./modules/node/node.pages.inc'),('node_body_field','function','./modules/node/node.pages.inc'),('node_form_delete_submit','function','./modules/node/node.pages.inc'),('node_form_build_preview','function','./modules/node/node.pages.inc'),('theme_node_form','function','./modules/node/node.pages.inc'),('node_preview','function','./modules/node/node.pages.inc'),('theme_node_preview','function','./modules/node/node.pages.inc'),('node_form_submit','function','./modules/node/node.pages.inc'),('node_form_submit_build_node','function','./modules/node/node.pages.inc'),('node_delete_confirm','function','./modules/node/node.pages.inc'),('node_delete_confirm_submit','function','./modules/node/node.pages.inc'),('node_revision_overview','function','./modules/node/node.pages.inc'),('node_revision_revert_confirm','function','./modules/node/node.pages.inc'),('node_revision_revert_confirm_submit','function','./modules/node/node.pages.inc'),('node_revision_delete_confirm','function','./modules/node/node.pages.inc'),('node_revision_delete_confirm_submit','function','./modules/node/node.pages.inc'),('user_module_invoke','function','./modules/user/user.module'),('user_theme','function','./modules/user/user.module'),('user_external_load','function','./modules/user/user.module'),('user_external_login','function','./modules/user/user.module'),('user_load','function','./modules/user/user.module'),('user_save','function','./modules/user/user.module'),('user_validate_name','function','./modules/user/user.module'),('user_validate_mail','function','./modules/user/user.module'),('user_validate_picture','function','./modules/user/user.module'),('user_password','function','./modules/user/user.module'),('user_role_permissions','function','./modules/user/user.module'),('user_access','function','./modules/user/user.module'),('user_is_blocked','function','./modules/user/user.module'),('user_perm','function','./modules/user/user.module'),('user_file_download','function','./modules/user/user.module'),('user_search','function','./modules/user/user.module'),('user_elements','function','./modules/user/user.module'),('user_user','function','./modules/user/user.module'),('user_login_block','function','./modules/user/user.module'),('user_block','function','./modules/user/user.module'),('template_preprocess_user_picture','function','./modules/user/user.module'),('theme_user_list','function','./modules/user/user.module'),('user_is_anonymous','function','./modules/user/user.module'),('user_is_logged_in','function','./modules/user/user.module'),('user_register_access','function','./modules/user/user.module'),('user_view_access','function','./modules/user/user.module'),('user_edit_access','function','./modules/user/user.module'),('user_load_self','function','./modules/user/user.module'),('user_menu','function','./modules/user/user.module'),('user_init','function','./modules/user/user.module'),('user_uid_optional_load','function','./modules/user/user.module'),('user_category_load','function','./modules/user/user.module'),('user_uid_optional_to_arg','function','./modules/user/user.module'),('user_page_title','function','./modules/user/user.module'),('user_get_authmaps','function','./modules/user/user.module'),('user_set_authmaps','function','./modules/user/user.module'),('user_login','function','./modules/user/user.module'),('user_login_default_validators','function','./modules/user/user.module'),('user_login_name_validate','function','./modules/user/user.module'),('user_login_authenticate_validate','function','./modules/user/user.module'),('user_login_final_validate','function','./modules/user/user.module'),('user_authenticate','function','./modules/user/user.module'),('user_authenticate_finalize','function','./modules/user/user.module'),('user_login_submit','function','./modules/user/user.module'),('user_external_login_register','function','./modules/user/user.module'),('user_pass_reset_url','function','./modules/user/user.module'),('user_pass_rehash','function','./modules/user/user.module'),('user_edit_form','function','./modules/user/user.module'),('_user_edit_validate','function','./modules/user/user.module'),('_user_edit_submit','function','./modules/user/user.module'),('user_delete','function','./modules/user/user.module'),('user_build_content','function','./modules/user/user.module'),('user_mail','function','./modules/user/user.module'),('_user_mail_text','function','./modules/user/user.module'),('user_roles','function','./modules/user/user.module'),('user_user_operations','function','./modules/user/user.module'),('user_user_operations_unblock','function','./modules/user/user.module'),('user_user_operations_block','function','./modules/user/user.module'),('user_multiple_role_edit','function','./modules/user/user.module'),('user_multiple_delete_confirm','function','./modules/user/user.module'),('user_multiple_delete_confirm_submit','function','./modules/user/user.module'),('user_help','function','./modules/user/user.module'),('_user_categories','function','./modules/user/user.module'),('_user_sort','function','./modules/user/user.module'),('user_filters','function','./modules/user/user.module'),('user_build_filter_query','function','./modules/user/user.module'),('user_forms','function','./modules/user/user.module'),('user_comment','function','./modules/user/user.module'),('theme_user_signature','function','./modules/user/user.module'),('user_mail_tokens','function','./modules/user/user.module'),('user_preferred_language','function','./modules/user/user.module'),('_user_mail_notify','function','./modules/user/user.module'),('_user_password_dynamic_validation','function','./modules/user/user.module'),('user_hook_info','function','./modules/user/user.module'),('user_action_info','function','./modules/user/user.module'),('user_block_user_action','function','./modules/user/user.module'),('user_register_submit','function','./modules/user/user.module'),('user_register','function','./modules/user/user.module'),('user_register_validate','function','./modules/user/user.module'),('_user_forms','function','./modules/user/user.module'),('user_admin','function','./modules/user/user.admin.inc'),('user_filter_form','function','./modules/user/user.admin.inc'),('user_filter_form_submit','function','./modules/user/user.admin.inc'),('user_admin_account','function','./modules/user/user.admin.inc'),('user_admin_account_submit','function','./modules/user/user.admin.inc'),('user_admin_account_validate','function','./modules/user/user.admin.inc'),('user_admin_settings','function','./modules/user/user.admin.inc'),('user_admin_perm','function','./modules/user/user.admin.inc'),('user_admin_perm_submit','function','./modules/user/user.admin.inc'),('theme_user_admin_perm','function','./modules/user/user.admin.inc'),('user_admin_role','function','./modules/user/user.admin.inc'),('user_admin_role_validate','function','./modules/user/user.admin.inc'),('user_admin_role_submit','function','./modules/user/user.admin.inc'),('theme_user_admin_account','function','./modules/user/user.admin.inc'),('theme_user_admin_new_role','function','./modules/user/user.admin.inc'),('theme_user_filter_form','function','./modules/user/user.admin.inc'),('theme_user_filters','function','./modules/user/user.admin.inc'),('user_autocomplete','function','./modules/user/user.pages.inc'),('user_pass','function','./modules/user/user.pages.inc'),('user_pass_validate','function','./modules/user/user.pages.inc'),('user_pass_submit','function','./modules/user/user.pages.inc'),('user_pass_reset','function','./modules/user/user.pages.inc'),('user_logout','function','./modules/user/user.pages.inc'),('user_view','function','./modules/user/user.pages.inc'),('template_preprocess_user_profile','function','./modules/user/user.pages.inc'),('template_preprocess_user_profile_item','function','./modules/user/user.pages.inc'),('template_preprocess_user_profile_category','function','./modules/user/user.pages.inc'),('user_edit','function','./modules/user/user.pages.inc'),('user_profile_form','function','./modules/user/user.pages.inc'),('user_profile_form_validate','function','./modules/user/user.pages.inc'),('user_profile_form_submit','function','./modules/user/user.pages.inc'),('user_edit_delete_submit','function','./modules/user/user.pages.inc'),('user_confirm_delete','function','./modules/user/user.pages.inc'),('user_confirm_delete_submit','function','./modules/user/user.pages.inc'),('user_edit_validate','function','./modules/user/user.pages.inc'),('user_edit_submit','function','./modules/user/user.pages.inc'),('user_page','function','./modules/user/user.pages.inc'),('color_help','function','./modules/color/color.module'),('color_theme','function','./modules/color/color.module'),('color_form_alter','function','./modules/color/color.module'),('_color_page_alter','function','./modules/color/color.module'),('color_get_info','function','./modules/color/color.module'),('color_get_palette','function','./modules/color/color.module'),('color_scheme_form','function','./modules/color/color.module'),('theme_color_scheme_form','function','./modules/color/color.module'),('color_scheme_form_submit','function','./modules/color/color.module'),('_color_rewrite_stylesheet','function','./modules/color/color.module'),('_color_save_stylesheet','function','./modules/color/color.module'),('_color_render_images','function','./modules/color/color.module'),('_color_shift','function','./modules/color/color.module'),('_color_gd','function','./modules/color/color.module'),('_color_blend','function','./modules/color/color.module'),('_color_unpack','function','./modules/color/color.module'),('_color_pack','function','./modules/color/color.module'),('_color_hsl2rgb','function','./modules/color/color.module'),('_color_hue2rgb','function','./modules/color/color.module'),('_color_rgb2hsl','function','./modules/color/color.module'),('comment_help','function','./modules/comment/comment.module'),('comment_theme','function','./modules/comment/comment.module'),('comment_menu','function','./modules/comment/comment.module'),('comment_node_type','function','./modules/comment/comment.module'),('comment_perm','function','./modules/comment/comment.module'),('comment_block','function','./modules/comment/comment.module'),('comment_get_recent','function','./modules/comment/comment.module'),('comment_new_page_count','function','./modules/comment/comment.module'),('theme_comment_block','function','./modules/comment/comment.module'),('comment_link','function','./modules/comment/comment.module'),('comment_form_alter','function','./modules/comment/comment.module'),('comment_nodeapi','function','./modules/comment/comment.module'),('comment_user','function','./modules/comment/comment.module'),('comment_access','function','./modules/comment/comment.module'),('comment_node_url','function','./modules/comment/comment.module'),('comment_save','function','./modules/comment/comment.module'),('comment_links','function','./modules/comment/comment.module'),('comment_render','function','./modules/comment/comment.module'),('comment_operations','function','./modules/comment/comment.module'),('comment_load','function','./modules/comment/comment.module'),('comment_num_all','function','./modules/comment/comment.module'),('comment_num_replies','function','./modules/comment/comment.module'),('comment_num_new','function','./modules/comment/comment.module'),('comment_validate','function','./modules/comment/comment.module'),('comment_form','function','./modules/comment/comment.module'),('comment_form_box','function','./modules/comment/comment.module'),('comment_form_add_preview','function','./modules/comment/comment.module'),('comment_form_validate','function','./modules/comment/comment.module'),('_comment_form_submit','function','./modules/comment/comment.module'),('comment_form_submit','function','./modules/comment/comment.module'),('theme_comment_view','function','./modules/comment/comment.module'),('template_preprocess_comment','function','./modules/comment/comment.module'),('template_preprocess_comment_folded','function','./modules/comment/comment.module'),('theme_comment_flat_collapsed','function','./modules/comment/comment.module'),('theme_comment_flat_expanded','function','./modules/comment/comment.module'),('theme_comment_thread_collapsed','function','./modules/comment/comment.module'),('theme_comment_thread_expanded','function','./modules/comment/comment.module'),('theme_comment_post_forbidden','function','./modules/comment/comment.module'),('template_preprocess_comment_wrapper','function','./modules/comment/comment.module'),('theme_comment_submitted','function','./modules/comment/comment.module'),('_comment_get_modes','function','./modules/comment/comment.module'),('_comment_get_orders','function','./modules/comment/comment.module'),('_comment_per_page','function','./modules/comment/comment.module'),('_comment_get_display_setting','function','./modules/comment/comment.module'),('_comment_update_node_statistics','function','./modules/comment/comment.module'),('comment_invoke_comment','function','./modules/comment/comment.module'),('int2vancode','function','./modules/comment/comment.module'),('vancode2int','function','./modules/comment/comment.module'),('comment_hook_info','function','./modules/comment/comment.module'),('comment_action_info','function','./modules/comment/comment.module'),('comment_unpublish_action','function','./modules/comment/comment.module'),('comment_unpublish_by_keyword_action_form','function','./modules/comment/comment.module'),('comment_unpublish_by_keyword_action_submit','function','./modules/comment/comment.module'),('comment_unpublish_by_keyword_action','function','./modules/comment/comment.module'),('comment_ranking','function','./modules/comment/comment.module'),('comment_admin','function','./modules/comment/comment.admin.inc'),('comment_admin_overview','function','./modules/comment/comment.admin.inc'),('comment_admin_overview_validate','function','./modules/comment/comment.admin.inc'),('comment_admin_overview_submit','function','./modules/comment/comment.admin.inc'),('theme_comment_admin_overview','function','./modules/comment/comment.admin.inc'),('comment_multiple_delete_confirm','function','./modules/comment/comment.admin.inc'),('comment_multiple_delete_confirm_submit','function','./modules/comment/comment.admin.inc'),('comment_delete','function','./modules/comment/comment.admin.inc'),('comment_confirm_delete','function','./modules/comment/comment.admin.inc'),('comment_confirm_delete_submit','function','./modules/comment/comment.admin.inc'),('_comment_delete_thread','function','./modules/comment/comment.admin.inc'),('comment_edit','function','./modules/comment/comment.pages.inc'),('comment_reply','function','./modules/comment/comment.pages.inc'),('help_menu','function','./modules/help/help.module'),('help_help','function','./modules/help/help.module'),('help_main','function','./modules/help/help.admin.inc'),('help_page','function','./modules/help/help.admin.inc'),('help_links_as_list','function','./modules/help/help.admin.inc'),('menu_help','function','./modules/menu/menu.module'),('menu_perm','function','./modules/menu/menu.module'),('menu_menu','function','./modules/menu/menu.module'),('menu_theme','function','./modules/menu/menu.module'),('menu_enable','function','./modules/menu/menu.module'),('menu_overview_title','function','./modules/menu/menu.module'),('menu_load','function','./modules/menu/menu.module'),('menu_parent_options','function','./modules/menu/menu.module'),('_menu_parents_recurse','function','./modules/menu/menu.module'),('menu_reset_item','function','./modules/menu/menu.module'),('menu_block','function','./modules/menu/menu.module'),('menu_nodeapi','function','./modules/menu/menu.module'),('_menu_parent_depth_limit','function','./modules/menu/menu.module'),('menu_form_alter','function','./modules/menu/menu.module'),('menu_node_form_submit','function','./modules/menu/menu.module'),('menu_get_menus','function','./modules/menu/menu.module'),('menu_overview_page','function','./modules/menu/menu.admin.inc'),('menu_overview_form','function','./modules/menu/menu.admin.inc'),('_menu_overview_tree_form','function','./modules/menu/menu.admin.inc'),('menu_overview_form_submit','function','./modules/menu/menu.admin.inc'),('theme_menu_overview_form','function','./modules/menu/menu.admin.inc'),('menu_edit_item','function','./modules/menu/menu.admin.inc'),('menu_edit_item_validate','function','./modules/menu/menu.admin.inc'),('menu_item_delete_submit','function','./modules/menu/menu.admin.inc'),('menu_edit_item_submit','function','./modules/menu/menu.admin.inc'),('menu_edit_menu','function','./modules/menu/menu.admin.inc'),('menu_custom_delete_submit','function','./modules/menu/menu.admin.inc'),('menu_delete_menu_page','function','./modules/menu/menu.admin.inc'),('menu_delete_menu_confirm','function','./modules/menu/menu.admin.inc'),('menu_delete_menu_confirm_submit','function','./modules/menu/menu.admin.inc'),('menu_edit_menu_validate','function','./modules/menu/menu.admin.inc'),('menu_edit_menu_submit','function','./modules/menu/menu.admin.inc'),('menu_item_delete_page','function','./modules/menu/menu.admin.inc'),('menu_item_delete_form','function','./modules/menu/menu.admin.inc'),('menu_item_delete_form_submit','function','./modules/menu/menu.admin.inc'),('menu_reset_item_confirm','function','./modules/menu/menu.admin.inc'),('menu_reset_item_confirm_submit','function','./modules/menu/menu.admin.inc'),('menu_configure','function','./modules/menu/menu.admin.inc'),('taxonomy_perm','function','./modules/taxonomy/taxonomy.module'),('taxonomy_theme','function','./modules/taxonomy/taxonomy.module'),('taxonomy_link','function','./modules/taxonomy/taxonomy.module'),('taxonomy_term_path','function','./modules/taxonomy/taxonomy.module'),('taxonomy_menu','function','./modules/taxonomy/taxonomy.module'),('taxonomy_save_vocabulary','function','./modules/taxonomy/taxonomy.module'),('taxonomy_del_vocabulary','function','./modules/taxonomy/taxonomy.module'),('taxonomy_check_vocabulary_hierarchy','function','./modules/taxonomy/taxonomy.module'),('taxonomy_save_term','function','./modules/taxonomy/taxonomy.module'),('taxonomy_del_term','function','./modules/taxonomy/taxonomy.module'),('taxonomy_form','function','./modules/taxonomy/taxonomy.module'),('taxonomy_form_all','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_vocabularies','function','./modules/taxonomy/taxonomy.module'),('taxonomy_form_alter','function','./modules/taxonomy/taxonomy.module'),('taxonomy_preview_terms','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_get_terms_by_vocabulary','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_get_terms','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_validate','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_save','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_delete','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_delete_revision','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_type','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_related','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_parents','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_parents_all','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_children','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_tree','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_synonyms','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_synonym_root','function','./modules/taxonomy/taxonomy.module'),('taxonomy_term_count_nodes','function','./modules/taxonomy/taxonomy.module'),('_taxonomy_term_children','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_term_by_name','function','./modules/taxonomy/taxonomy.module'),('taxonomy_vocabulary_load','function','./modules/taxonomy/taxonomy.module'),('taxonomy_get_term','function','./modules/taxonomy/taxonomy.module'),('_taxonomy_term_select','function','./modules/taxonomy/taxonomy.module'),('theme_taxonomy_term_select','function','./modules/taxonomy/taxonomy.module'),('taxonomy_select_nodes','function','./modules/taxonomy/taxonomy.module'),('taxonomy_render_nodes','function','./modules/taxonomy/taxonomy.module'),('taxonomy_nodeapi','function','./modules/taxonomy/taxonomy.module'),('taxonomy_node_update_index','function','./modules/taxonomy/taxonomy.module'),('taxonomy_terms_parse_string','function','./modules/taxonomy/taxonomy.module'),('taxonomy_rss_item','function','./modules/taxonomy/taxonomy.module'),('taxonomy_help','function','./modules/taxonomy/taxonomy.module'),('_taxonomy_get_tid_from_term','function','./modules/taxonomy/taxonomy.module'),('taxonomy_implode_tags','function','./modules/taxonomy/taxonomy.module'),('taxonomy_hook_info','function','./modules/taxonomy/taxonomy.module'),('taxonomy_overview_vocabularies','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_overview_vocabularies_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('theme_taxonomy_overview_vocabularies','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_form_vocabulary','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_form_vocabulary_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_admin_vocabulary_edit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_admin_term_edit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_overview_terms','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_overview_terms_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('theme_taxonomy_overview_terms','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_add_term_page','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_form_term','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_form_term_validate','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_form_term_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_term_confirm_parents','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_term_confirm_delete','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_term_confirm_delete_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_vocabulary_confirm_delete','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_vocabulary_confirm_delete_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_vocabulary_confirm_reset_alphabetical','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_vocabulary_confirm_reset_alphabetical_submit','function','./modules/taxonomy/taxonomy.admin.inc'),('taxonomy_term_page','function','./modules/taxonomy/taxonomy.pages.inc'),('theme_taxonomy_term_page','function','./modules/taxonomy/taxonomy.pages.inc'),('taxonomy_autocomplete','function','./modules/taxonomy/taxonomy.pages.inc'),('dblog_help','function','./modules/dblog/dblog.module'),('dblog_theme','function','./modules/dblog/dblog.module'),('dblog_menu','function','./modules/dblog/dblog.module'),('dblog_init','function','./modules/dblog/dblog.module'),('dblog_cron','function','./modules/dblog/dblog.module'),('dblog_user','function','./modules/dblog/dblog.module'),('_dblog_get_message_types','function','./modules/dblog/dblog.module'),('dblog_watchdog','function','./modules/dblog/dblog.module'),('theme_dblog_filters','function','./modules/dblog/dblog.module'),('dblog_admin_settings','function','./modules/dblog/dblog.admin.inc'),('dblog_overview','function','./modules/dblog/dblog.admin.inc'),('dblog_top','function','./modules/dblog/dblog.admin.inc'),('dblog_event','function','./modules/dblog/dblog.admin.inc'),('dblog_build_filter_query','function','./modules/dblog/dblog.admin.inc'),('dblog_filters','function','./modules/dblog/dblog.admin.inc'),('_dblog_format_message','function','./modules/dblog/dblog.admin.inc'),('dblog_filter_form','function','./modules/dblog/dblog.admin.inc'),('dblog_filter_form_validate','function','./modules/dblog/dblog.admin.inc'),('dblog_filter_form_submit','function','./modules/dblog/dblog.admin.inc');
/*!40000 ALTER TABLE `registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registry_file`
--

DROP TABLE IF EXISTS `registry_file`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `registry_file` (
  `filename` varchar(255) NOT NULL,
  `md5` varchar(32) NOT NULL,
  PRIMARY KEY  (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `registry_file`
--

LOCK TABLES `registry_file` WRITE;
/*!40000 ALTER TABLE `registry_file` DISABLE KEYS */;
INSERT INTO `registry_file` (`filename`, `md5`) VALUES ('./modules/block/block.module','bc4611be646eb6fda83a41ee9b556104'),('./modules/block/block.admin.inc','98824cd5fecc43c02c37840e3f6d981f'),('./modules/system/system.module','998974ac15ef0e39edbafe04e317642f'),('./modules/system/system.admin.inc','7d4382572eb1d294cf825ca9f2ae7d90'),('./includes/actions.inc','25e1e96a2e0ae3f44305f6611b096dbe'),('./includes/batch.inc','d344b88ce9b59f89a8c2898c603f4ed1'),('./includes/bootstrap.inc','0fb4ea778177c41eddf336f9d4e9a441'),('./includes/cache-install.inc','cd3c6af1d5b2f8fa9e517a81dbffdec9'),('./includes/cache.inc','f21a911753e7589bc9a4d6059f3f0e62'),('./includes/common.inc','bee7224fde93a44cd0c269043b8aff51'),('./includes/database.inc','6df2f8969774a44cd92ecce090a38b32'),('./includes/database.mysql-common.inc','9bb07113be4e4fdd1e40280cca0c5af4'),('./includes/database.mysql.inc','2174178b274944d25eb91be95725e1a5'),('./includes/database.mysqli.inc','9c0c4913f2022c9a3c4ad47f5ff56601'),('./includes/database.pgsql.inc','6ceb42752a70c229a5c95022dda83e04'),('./includes/file.inc','9f1a64d3fdcc384a1cffc67d78db3198'),('./includes/form.inc','75bbc39a529b1e8b86d626163ffec2af'),('./includes/image.gd.inc','a5951f4cab408321ab249963625a3cd4'),('./includes/image.inc','c277c6f897f0d4fd96ba6648e5cf2f78'),('./includes/install.inc','8480b1d8f7a2a79d1deb0131b0b8d9d6'),('./includes/install.mysql.inc','72a235c60947409ee284c6e1839850eb'),('./includes/install.mysqli.inc','e65396149bd6a14bed0ff87f1b470eed'),('./includes/install.pgsql.inc','55409071bf6e166af1674f1407ec1437'),('./includes/language.inc','85c16a68c4dff5165e11584c9483b6d5'),('./includes/locale.inc','a89352013cf614c6db9c27bbe0e2e6bc'),('./includes/mail.inc','b0dcad88dc484efb013527feab75d5a9'),('./includes/menu.inc','116319e6c7888f950232b9e725c6b9d3'),('./includes/module.inc','afb924c34238ca9c41e105c703687743'),('./includes/pager.inc','bd3c3b8aecf00edb9122ae06456b7023'),('./includes/password.inc','689559817113dd4c6556c558d1366604'),('./includes/path.inc','6d17ae937ed54eae6ea47e531c412c8e'),('./includes/registry.inc','1fc848c108756e412a81ac2b72747e5f'),('./includes/session.inc','b1698142635a3a44747d61407cafb48f'),('./includes/tablesort.inc','1ce5a14e3571c33c2c6ade3328beccf9'),('./includes/theme.inc','439e32e0d4c2e211467bf7a7d00676c7'),('./includes/theme.maintenance.inc','1d6e726afb2945db40e17410265e307c'),('./includes/unicode.inc','3a7729668bc6d5c61c9f8b2534c612b7'),('./includes/xmlrpc.inc','6959265b8793be8dc0bc598a1643ec3e'),('./includes/xmlrpcs.inc','46c052ff4659a80e77246fb20502ad4a'),('./modules/filter/filter.module','b9ff146926a0f3173fcf195c4dd0fecb'),('./modules/filter/filter.admin.inc','4dcf40f750868b2ab4e9f3940a8069b9'),('./modules/filter/filter.pages.inc','d6a085b2bfa9782a9639bf80d8df81a9'),('./modules/node/node.module','c3ec028ec0fdd92577d8ad1a6b7f109f'),('./modules/node/content_types.inc','40f7be7ba471f6a4dcecad0c5769322f'),('./modules/node/node.admin.inc','02c8cf060ee5b394cfb868976bee7707'),('./modules/node/node.pages.inc','f243ec214df6df534529f2b893eeff6d'),('./modules/user/user.module','c436bf1e437be5b4951d15fe764f6819'),('./modules/user/user.admin.inc','9d0c790ec7a92d6d580a3ad39b979abb'),('./modules/user/user.pages.inc','67f67ded0b3ccaa293bd4a1bc0d48afb'),('./modules/color/color.module','989609af8a2dc4fb19528178601ed09b'),('./modules/comment/comment.module','4e19e43675de7c0ccee88c072b0b2ef5'),('./modules/comment/comment.admin.inc','4cb3e33c1afff165f6c4cf622ce7a5c0'),('./modules/comment/comment.pages.inc','7a6998f87332ae0136adc454601c6311'),('./modules/help/help.module','0508848e9d06f901563ed5468519e1ec'),('./modules/help/help.admin.inc','192e3adf4d131a965090ec86dced75b0'),('./modules/menu/menu.module','e9ae89fde03ccde2ecb8e4ec17402c0c'),('./modules/menu/menu.admin.inc','20a5477058492b5a42cf894d63be14b4'),('./modules/taxonomy/taxonomy.module','1f027a207e03fd55590f1af99dc26f71'),('./modules/taxonomy/taxonomy.admin.inc','0f4d68f2cebe8a78af099c3e8cbe3b58'),('./modules/taxonomy/taxonomy.pages.inc','0ff2d076e66d26070da0979816793c63'),('./modules/dblog/dblog.module','66210cf8f2f442a605dc22d957998884'),('./modules/dblog/dblog.admin.inc','ac2ba3625b343814862e55637d3ce777');
/*!40000 ALTER TABLE `registry_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role` (
  `rid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`rid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`rid`, `name`) VALUES (1,'anonymous user'),(2,'authenticated user');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_permission` (
  `rid` int(10) unsigned NOT NULL,
  `permission` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`rid`,`permission`),
  KEY `permission` (`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` (`rid`, `permission`) VALUES (1,'access content'),(2,'access comments'),(2,'access content'),(2,'post comments'),(2,'post comments without approval');
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sessions` (
  `uid` int(10) unsigned NOT NULL,
  `sid` varchar(64) NOT NULL default '',
  `hostname` varchar(128) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  `cache` int(11) NOT NULL default '0',
  `session` longtext,
  PRIMARY KEY  (`sid`),
  KEY `timestamp` (`timestamp`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`uid`, `sid`, `hostname`, `timestamp`, `cache`, `session`) VALUES (1,'3f37ea574b7a75775b3c9d0d80a36a42','127.0.0.1',1211588457,0,'messages|s:0:\"\";');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system`
--

DROP TABLE IF EXISTS `system`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `system` (
  `filename` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `type` varchar(255) NOT NULL default '',
  `owner` varchar(255) NOT NULL default '',
  `status` int(11) NOT NULL default '0',
  `throttle` tinyint(4) NOT NULL default '0',
  `bootstrap` int(11) NOT NULL default '0',
  `schema_version` smallint(6) NOT NULL default '-1',
  `weight` int(11) NOT NULL default '0',
  `info` text,
  PRIMARY KEY  (`filename`),
  KEY `modules` (`type`(12),`status`,`weight`,`filename`),
  KEY `bootstrap` (`type`(12),`status`,`bootstrap`,`weight`,`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `system`
--

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `throttle`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES ('themes/pushbutton/pushbutton.info','pushbutton','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:11:{s:4:\"name\";s:10:\"Pushbutton\";s:11:\"description\";s:52:\"Tabled, multi-column theme in blue and orange tones.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/pushbutton/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/pushbutton/script.js\";}s:10:\"screenshot\";s:32:\"themes/pushbutton/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}'),('themes/garland/minnelli/minnelli.info','minnelli','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:12:{s:4:\"name\";s:8:\"Minnelli\";s:11:\"description\";s:56:\"Tableless, recolorable, multi-column, fixed width theme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:7:\"garland\";s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:12:\"minnelli.css\";s:36:\"themes/garland/minnelli/minnelli.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/garland/minnelli/script.js\";}s:10:\"screenshot\";s:38:\"themes/garland/minnelli/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";s:6:\"engine\";s:11:\"phptemplate\";}'),('themes/garland/garland.info','garland','theme','themes/engines/phptemplate/phptemplate.engine',1,0,0,-1,0,'a:11:{s:4:\"name\";s:7:\"Garland\";s:11:\"description\";s:66:\"Tableless, recolorable, multi-column, fluid width theme (default).\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:11:\"stylesheets\";a:2:{s:3:\"all\";a:1:{s:9:\"style.css\";s:24:\"themes/garland/style.css\";}s:5:\"print\";a:1:{s:9:\"print.css\";s:24:\"themes/garland/print.css\";}}s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:24:\"themes/garland/script.js\";}s:10:\"screenshot\";s:29:\"themes/garland/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}'),('themes/chameleon/marvin/marvin.info','marvin','theme','',0,0,0,-1,0,'a:11:{s:4:\"name\";s:6:\"Marvin\";s:11:\"description\";s:31:\"Boxy tabled theme in all grays.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:10:\"base theme\";s:9:\"chameleon\";s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:33:\"themes/chameleon/marvin/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:33:\"themes/chameleon/marvin/script.js\";}s:10:\"screenshot\";s:38:\"themes/chameleon/marvin/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}'),('themes/chameleon/chameleon.info','chameleon','theme','themes/chameleon/chameleon.theme',0,0,0,-1,0,'a:10:{s:4:\"name\";s:9:\"Chameleon\";s:11:\"description\";s:42:\"Minimalist tabled theme with light colors.\";s:7:\"regions\";a:2:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";}s:8:\"features\";a:4:{i:0;s:4:\"logo\";i:1;s:7:\"favicon\";i:2;s:4:\"name\";i:3;s:6:\"slogan\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:2:{s:9:\"style.css\";s:26:\"themes/chameleon/style.css\";s:10:\"common.css\";s:27:\"themes/chameleon/common.css\";}}s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:7:\"scripts\";a:1:{s:9:\"script.js\";s:26:\"themes/chameleon/script.js\";}s:10:\"screenshot\";s:31:\"themes/chameleon/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}'),('themes/bluemarine/bluemarine.info','bluemarine','theme','themes/engines/phptemplate/phptemplate.engine',0,0,0,-1,0,'a:11:{s:4:\"name\";s:10:\"Bluemarine\";s:11:\"description\";s:51:\"Tableless theme with a marine and ash color scheme.\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:6:\"engine\";s:11:\"phptemplate\";s:7:\"regions\";a:5:{s:4:\"left\";s:12:\"Left sidebar\";s:5:\"right\";s:13:\"Right sidebar\";s:7:\"content\";s:7:\"Content\";s:6:\"header\";s:6:\"Header\";s:6:\"footer\";s:6:\"Footer\";}s:8:\"features\";a:10:{i:0;s:20:\"comment_user_picture\";i:1;s:7:\"favicon\";i:2;s:7:\"mission\";i:3;s:4:\"logo\";i:4;s:4:\"name\";i:5;s:17:\"node_user_picture\";i:6;s:6:\"search\";i:7;s:6:\"slogan\";i:8;s:13:\"primary_links\";i:9;s:15:\"secondary_links\";}s:11:\"stylesheets\";a:1:{s:3:\"all\";a:1:{s:9:\"style.css\";s:27:\"themes/bluemarine/style.css\";}}s:7:\"scripts\";a:1:{s:9:\"script.js\";s:27:\"themes/bluemarine/script.js\";}s:10:\"screenshot\";s:32:\"themes/bluemarine/screenshot.png\";s:3:\"php\";s:5:\"5.2.0\";}'),('modules/system/system.module','system','module','',1,0,0,7008,0,'a:9:{s:4:\"name\";s:6:\"System\";s:11:\"description\";s:54:\"Handles general site configuration for administrators.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:13:\"system.module\";i:1;s:16:\"system.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/aggregator/aggregator.module','aggregator','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:10:\"Aggregator\";s:11:\"description\";s:57:\"Aggregates syndicated content (RSS, RDF, and Atom feeds).\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:17:\"aggregator.module\";i:1;s:20:\"aggregator.admin.inc\";i:2;s:20:\"aggregator.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/block/block.module','block','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:5:\"Block\";s:11:\"description\";s:62:\"Controls the boxes that are displayed around the main content.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:12:\"block.module\";i:1;s:15:\"block.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/blog/blog.module','blog','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:4:\"Blog\";s:11:\"description\";s:69:\"Enables keeping easily and regularly updated user web pages or blogs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:11:\"blog.module\";i:1;s:14:\"blog.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/blogapi/blogapi.module','blogapi','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:8:\"Blog API\";s:11:\"description\";s:79:\"Allows users to post content using applications that support XML-RPC blog APIs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:1:{i:0;s:14:\"blogapi.module\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/book/book.module','book','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:4:\"Book\";s:11:\"description\";s:63:\"Allows users to structure site pages in a hierarchy or outline.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:11:\"book.module\";i:1;s:14:\"book.admin.inc\";i:2;s:14:\"book.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/color/color.module','color','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:5:\"Color\";s:11:\"description\";s:70:\"Allows administrators to change the color scheme of compatible themes.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:1:{i:0;s:12:\"color.module\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/comment/comment.module','comment','module','',1,0,0,6003,0,'a:9:{s:4:\"name\";s:7:\"Comment\";s:11:\"description\";s:57:\"Allows users to comment on and discuss published content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:14:\"comment.module\";i:1;s:17:\"comment.admin.inc\";i:2;s:17:\"comment.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/contact/contact.module','contact','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:7:\"Contact\";s:11:\"description\";s:61:\"Enables the use of both personal and site-wide contact forms.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:14:\"contact.module\";i:1;s:17:\"contact.admin.inc\";i:2;s:17:\"contact.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/dblog/dblog.module','dblog','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:16:\"Database logging\";s:11:\"description\";s:47:\"Logs and records system events to the database.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:12:\"dblog.module\";i:1;s:15:\"dblog.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/filter/filter.module','filter','module','',1,0,0,7001,0,'a:9:{s:4:\"name\";s:6:\"Filter\";s:11:\"description\";s:60:\"Handles the filtering of content in preparation for display.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:13:\"filter.module\";i:1;s:16:\"filter.admin.inc\";i:2;s:16:\"filter.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/forum/forum.module','forum','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:5:\"Forum\";s:11:\"description\";s:50:\"Enables threaded discussions about general topics.\";s:12:\"dependencies\";a:2:{i:0;s:8:\"taxonomy\";i:1;s:7:\"comment\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:12:\"forum.module\";i:1;s:15:\"forum.admin.inc\";i:2;s:15:\"forum.pages.inc\";}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/help/help.module','help','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:4:\"Help\";s:11:\"description\";s:35:\"Manages the display of online help.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:11:\"help.module\";i:1;s:14:\"help.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/locale/locale.module','locale','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:6:\"Locale\";s:11:\"description\";s:119:\"Adds language handling functionality and enables the translation of the user interface to languages other than English.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:1:{i:0;s:13:\"locale.module\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/menu/menu.module','menu','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:4:\"Menu\";s:11:\"description\";s:60:\"Allows administrators to customize the site navigation menu.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:11:\"menu.module\";i:1;s:14:\"menu.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/node/node.module','node','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:4:\"Node\";s:11:\"description\";s:66:\"Allows content to be submitted to the site and displayed on pages.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:4:{i:0;s:11:\"node.module\";i:1;s:17:\"content_types.inc\";i:2;s:14:\"node.admin.inc\";i:3;s:14:\"node.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/openid/openid.module','openid','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:6:\"OpenID\";s:11:\"description\";s:48:\"Allows users to log into your site using OpenID.\";s:7:\"version\";s:7:\"7.0-dev\";s:7:\"package\";s:15:\"Core - optional\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:4:{i:0;s:13:\"openid.module\";i:1;s:10:\"openid.inc\";i:2;s:16:\"openid.pages.inc\";i:3;s:8:\"xrds.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/path/path.module','path','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:4:\"Path\";s:11:\"description\";s:28:\"Allows users to rename URLs.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:11:\"path.module\";i:1;s:14:\"path.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/php/php.module','php','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:10:\"PHP filter\";s:11:\"description\";s:50:\"Allows embedded PHP code/snippets to be evaluated.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:1:{i:0;s:10:\"php.module\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/poll/poll.module','poll','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:4:\"Poll\";s:11:\"description\";s:95:\"Allows your site to capture votes on different topics in the form of multiple choice questions.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:11:\"poll.module\";i:1;s:14:\"poll.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/profile/profile.module','profile','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:7:\"Profile\";s:11:\"description\";s:36:\"Supports configurable user profiles.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:14:\"profile.module\";i:1;s:17:\"profile.admin.inc\";i:2;s:17:\"profile.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/search/search.module','search','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:6:\"Search\";s:11:\"description\";s:36:\"Enables site-wide keyword searching.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:13:\"search.module\";i:1;s:16:\"search.admin.inc\";i:2;s:16:\"search.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/statistics/statistics.module','statistics','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:10:\"Statistics\";s:11:\"description\";s:37:\"Logs access statistics for your site.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:17:\"statistics.module\";i:1;s:20:\"statistics.admin.inc\";i:2;s:20:\"statistics.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/syslog/syslog.module','syslog','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:6:\"Syslog\";s:11:\"description\";s:41:\"Logs and records system events to syslog.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:1:{i:0;s:13:\"syslog.module\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/taxonomy/taxonomy.module','taxonomy','module','',1,0,0,0,0,'a:9:{s:4:\"name\";s:8:\"Taxonomy\";s:11:\"description\";s:38:\"Enables the categorization of content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:15:\"taxonomy.module\";i:1;s:18:\"taxonomy.admin.inc\";i:2;s:18:\"taxonomy.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/tracker/tracker.module','tracker','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:7:\"Tracker\";s:11:\"description\";s:43:\"Enables tracking of recent posts for users.\";s:12:\"dependencies\";a:1:{i:0;s:7:\"comment\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:14:\"tracker.module\";i:1;s:17:\"tracker.pages.inc\";}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/translation/translation.module','translation','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:19:\"Content translation\";s:11:\"description\";s:57:\"Allows content to be translated into different languages.\";s:12:\"dependencies\";a:1:{i:0;s:6:\"locale\";}s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:18:\"translation.module\";i:1;s:21:\"translation.pages.inc\";}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/trigger/trigger.module','trigger','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:7:\"Trigger\";s:11:\"description\";s:90:\"Enables actions to be fired on certain system events, such as when new content is created.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:14:\"trigger.module\";i:1;s:17:\"trigger.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/update/update.module','update','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:13:\"Update status\";s:11:\"description\";s:88:\"Checks the status of available updates for Drupal and your installed modules and themes.\";s:7:\"version\";s:7:\"7.0-dev\";s:7:\"package\";s:15:\"Core - optional\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:5:{i:0;s:13:\"update.module\";i:1;s:18:\"update.compare.inc\";i:2;s:16:\"update.fetch.inc\";i:3;s:17:\"update.report.inc\";i:4;s:19:\"update.settings.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/upload/upload.module','upload','module','',0,0,0,-1,0,'a:9:{s:4:\"name\";s:6:\"Upload\";s:11:\"description\";s:51:\"Allows users to upload and attach files to content.\";s:7:\"package\";s:15:\"Core - optional\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:2:{i:0;s:13:\"upload.module\";i:1;s:16:\"upload.admin.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}'),('modules/user/user.module','user','module','',1,0,0,7001,0,'a:9:{s:4:\"name\";s:4:\"User\";s:11:\"description\";s:47:\"Manages the user registration and login system.\";s:7:\"package\";s:15:\"Core - required\";s:7:\"version\";s:7:\"7.0-dev\";s:4:\"core\";s:3:\"7.x\";s:5:\"files\";a:3:{i:0;s:11:\"user.module\";i:1;s:14:\"user.admin.inc\";i:2;s:14:\"user.pages.inc\";}s:12:\"dependencies\";a:0:{}s:10:\"dependents\";a:0:{}s:3:\"php\";s:5:\"5.2.0\";}');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_data`
--

DROP TABLE IF EXISTS `term_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `term_data` (
  `tid` int(10) unsigned NOT NULL auto_increment,
  `vid` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` longtext,
  `weight` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`tid`),
  KEY `taxonomy_tree` (`vid`,`weight`,`name`),
  KEY `vid_name` (`vid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `term_data`
--

LOCK TABLES `term_data` WRITE;
/*!40000 ALTER TABLE `term_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_hierarchy`
--

DROP TABLE IF EXISTS `term_hierarchy`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `term_hierarchy` (
  `tid` int(10) unsigned NOT NULL default '0',
  `parent` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tid`,`parent`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `term_hierarchy`
--

LOCK TABLES `term_hierarchy` WRITE;
/*!40000 ALTER TABLE `term_hierarchy` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_hierarchy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_node`
--

DROP TABLE IF EXISTS `term_node`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `term_node` (
  `nid` int(10) unsigned NOT NULL default '0',
  `vid` int(10) unsigned NOT NULL default '0',
  `tid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tid`,`vid`),
  KEY `vid` (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `term_node`
--

LOCK TABLES `term_node` WRITE;
/*!40000 ALTER TABLE `term_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_relation`
--

DROP TABLE IF EXISTS `term_relation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `term_relation` (
  `trid` int(11) NOT NULL auto_increment,
  `tid1` int(10) unsigned NOT NULL default '0',
  `tid2` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`trid`),
  UNIQUE KEY `tid1_tid2` (`tid1`,`tid2`),
  KEY `tid2` (`tid2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `term_relation`
--

LOCK TABLES `term_relation` WRITE;
/*!40000 ALTER TABLE `term_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term_synonym`
--

DROP TABLE IF EXISTS `term_synonym`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `term_synonym` (
  `tsid` int(11) NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`tsid`),
  KEY `tid` (`tid`),
  KEY `name_tid` (`name`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `term_synonym`
--

LOCK TABLES `term_synonym` WRITE;
/*!40000 ALTER TABLE `term_synonym` DISABLE KEYS */;
/*!40000 ALTER TABLE `term_synonym` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_alias`
--

DROP TABLE IF EXISTS `url_alias`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `url_alias` (
  `pid` int(10) unsigned NOT NULL auto_increment,
  `src` varchar(128) NOT NULL default '',
  `dst` varchar(128) NOT NULL default '',
  `language` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`pid`),
  UNIQUE KEY `dst_language` (`dst`,`language`),
  KEY `src` (`src`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `url_alias`
--

LOCK TABLES `url_alias` WRITE;
/*!40000 ALTER TABLE `url_alias` DISABLE KEYS */;
/*!40000 ALTER TABLE `url_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `pass` varchar(128) NOT NULL default '',
  `mail` varchar(64) default '',
  `theme` varchar(255) NOT NULL default '',
  `signature` varchar(255) NOT NULL default '',
  `created` int(11) NOT NULL default '0',
  `access` int(11) NOT NULL default '0',
  `login` int(11) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `timezone` varchar(8) default NULL,
  `language` varchar(12) NOT NULL default '',
  `picture` varchar(255) NOT NULL default '',
  `init` varchar(64) default '',
  `data` longtext,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `access` (`access`),
  KEY `created` (`created`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`uid`, `name`, `pass`, `mail`, `theme`, `signature`, `created`, `access`, `login`, `status`, `timezone`, `language`, `picture`, `init`, `data`) VALUES (0,'','','','','',0,0,0,0,NULL,'','','',NULL),(1,'amdin','$P$C6qsB3f.JGgLEJQGS2IEawziBO77xs/','brendoncrawford@gmail.com','','',1211588406,1211588453,1211588451,1,NULL,'','','brendoncrawford@gmail.com','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users_roles` (
  `uid` int(10) unsigned NOT NULL default '0',
  `rid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`uid`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variable`
--

DROP TABLE IF EXISTS `variable`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `variable` (
  `name` varchar(128) NOT NULL default '',
  `value` longtext NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `variable`
--

LOCK TABLES `variable` WRITE;
/*!40000 ALTER TABLE `variable` DISABLE KEYS */;
INSERT INTO `variable` (`name`, `value`) VALUES ('theme_default','S\'garland\'\np0\n.'),('filter_html_1','I1\n.'),('node_options_forum','(dp0\nI0\nS\'status\'\np1\ns.'),('cron_key','S\'1fd145b064488eea6cb9da2cad684fb9\'\np0\n.'),('drupal_private_key','S\'84fe844581eabc62997041983c7cd2a5\'\np0\n.'),('menu_masks','(dp0\nI0\nI62\nsI1\nI61\nsI2\nI59\nsI3\nI31\nsI4\nI30\nsI5\nI29\nsI6\nI24\nsI7\nI21\nsI8\nI15\nsI9\nI14\nsI10\nI11\nsI11\nI7\nsI12\nI6\nsI13\nI5\nsI14\nI3\nsI15\nI2\nsI16\nI1\ns.'),('install_task','S\'done\'\np0\n.'),('menu_expanded','(dp0\n.'),('site_name','S\'drupalhead.local\'\np0\n.'),('site_mail','S\'brendoncrawford@gmail.com\'\np0\n.'),('date_default_timezone','S\'-25200\'\np0\n.'),('user_email_verification','I01\n.'),('clean_url','S\'1\'\np0\n.'),('install_time','I1211588451\n.'),('node_options_page','(dp0\nI0\nS\'status\'\np1\ns.'),('comment_page','I0\n.'),('theme_settings','(dp0\nS\'toggle_node_info_page\'\np1\nI00\ns.'),('css_js_query_string','S\'g0000000000000000000\'\np0\n.'),('install_profile','S\'default\'\np0\n.');
/*!40000 ALTER TABLE `variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `vocabulary` (
  `vid` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` longtext,
  `help` varchar(255) NOT NULL default '',
  `relations` tinyint(3) unsigned NOT NULL default '0',
  `hierarchy` tinyint(3) unsigned NOT NULL default '0',
  `multiple` tinyint(3) unsigned NOT NULL default '0',
  `required` tinyint(3) unsigned NOT NULL default '0',
  `tags` tinyint(3) unsigned NOT NULL default '0',
  `module` varchar(255) NOT NULL default '',
  `weight` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`vid`),
  KEY `list` (`weight`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary_node_types`
--

DROP TABLE IF EXISTS `vocabulary_node_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `vocabulary_node_types` (
  `vid` int(10) unsigned NOT NULL default '0',
  `type` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`type`,`vid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `vocabulary_node_types`
--

LOCK TABLES `vocabulary_node_types` WRITE;
/*!40000 ALTER TABLE `vocabulary_node_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulary_node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchdog`
--

DROP TABLE IF EXISTS `watchdog`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `watchdog` (
  `wid` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL default '0',
  `type` varchar(16) NOT NULL default '',
  `message` longtext NOT NULL,
  `variables` longtext NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL default '0',
  `link` varchar(255) NOT NULL default '',
  `location` text NOT NULL,
  `referer` varchar(128) NOT NULL default '',
  `hostname` varchar(128) NOT NULL default '',
  `timestamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`wid`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `watchdog`
--

LOCK TABLES `watchdog` WRITE;
/*!40000 ALTER TABLE `watchdog` DISABLE KEYS */;
INSERT INTO `watchdog` (`wid`, `uid`, `type`, `message`, `variables`, `severity`, `link`, `location`, `referer`, `hostname`, `timestamp`) VALUES (1,1,'user','Session opened for %name.','a:1:{s:5:\"%name\";s:5:\"amdin\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588451),(2,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:17:\"Unpublish comment\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(3,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:12:\"Publish post\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(4,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:14:\"Unpublish post\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(5,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:16:\"Make post sticky\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(6,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:18:\"Make post unsticky\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(7,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:26:\"Promote post to front page\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(8,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:27:\"Remove post from front page\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(9,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:9:\"Save post\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(10,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:30:\"Ban IP address of current user\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453),(11,1,'actions','Action \'%action\' added.','a:1:{s:7:\"%action\";s:18:\"Block current user\";}',5,'','http://drupalhead.local/install.php?locale=en&profile=default','http://drupalhead.local/install.php?locale=en&profile=default','127.0.0.1',1211588453);
/*!40000 ALTER TABLE `watchdog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2008-06-17 20:01:14
